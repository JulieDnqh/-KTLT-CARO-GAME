﻿#include "Control.h"
#pragma comment(lib, "Winmm.lib")
using namespace std;

void gotoXY(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
void playSound(int id)
{
	mciSendString(L"close wav", NULL, 0, NULL);	//need to close first
	mciSendString(arrSound[id], NULL, 0, NULL);
	mciSendString(L"play wav", NULL, 0, NULL);
}

void Menu()
{
	ClearScreen(1, 0);
	Background();
	DrawObject(Caro, 2 * 16 + 9, nScreenWidth / 2 - Caro[0].length() / 2, 3);

	drawNotiBoard3(nScreenWidth / 2 - 6, 10, 12, 6);
	Text(L"NEW GAME", 5 * 16 + 6, nScreenWidth / 2 - 4, 11);
	drawNotiBoard3(nScreenWidth / 2 - 6, 13, 12, 6);
	Text(L"LOAD GAME", 5 * 16 + 2, nScreenWidth / 2 - 4, 14);
	drawNotiBoard3(nScreenWidth / 2 - 6, 16, 12, 6);
	Text(L"SETTING", 5 * 16 + 2, nScreenWidth / 2 - 3, 17);
	drawNotiBoard3(nScreenWidth / 2 - 6, 19, 12, 6);
	Text(L"HELP", 5 * 16 + 2, nScreenWidth / 2 - 2, 20);
	drawNotiBoard3(nScreenWidth / 2 - 6, 22, 12, 6);
	Text(L"ABOUT", 5 * 16 + 2, nScreenWidth / 2 - 2, 23);
	drawNotiBoard3(nScreenWidth / 2 - 6, 25, 12, 6);
	Text(L"EXIT", 5 * 16 + 2, nScreenWidth / 2 - 2, 26);

	Display();

	int nSelect = 1;

	while (1)
	{
		int move = toupper(_getch());

		if (move == 'S' || move == 80)
		{
			if (sound)
				playSound(4);

			nSelect++;
			if (nSelect > 6)
				nSelect -= 6;
		}
		if (move == 'W' || move == 72)
		{
			if (sound)
				playSound(4);

			nSelect--;
			if (nSelect < 1)
				nSelect += 6;
		}
		if (move == 13 || move == 32)
		{
			if (sound)
				playSound(0);

			switch (nSelect)
			{
			case 1:
			{
				NewGamePage();
				break;
			}
			case 2:
				LoadGamePage();
				break;
			case 3:
				ClearScreen(1, 0);
				Background();

				DrawObject(Setting, 2 * 16 + 4, nScreenWidth / 2 - Setting[0].length() / 2, 5);
				SettingPage(pBuffer, pColor);

				ClearScreen(1, 0);
				Background();
				break;
			case 4:
				ClearScreen(1, 0);
				Backgroundsub();

				DrawObject(Help, 2 * 16 + 10, nScreenWidth / 2 - Help[0].length() / 2, 3);
				HelpPage(pBuffer, pColor);

				ClearScreen(1, 0);
				Background();
				break;
			case 5:
				AboutPage();
				break;
			case 6:
				ExitPage();
				break;
			}
		}
		DrawObject(Caro, 2 * 16 + 9, nScreenWidth / 2 - Caro[0].length() / 2, 3);

		switch (nSelect)
		{
		case 1:
		{
			drawNotiBoard3(nScreenWidth / 2 - 6, 10, 12, 6);
			Text(L"NEW GAME", 5 * 16 + 6, nScreenWidth / 2 - 4, 11);
			drawNotiBoard3(nScreenWidth / 2 - 6, 13, 12, 6);
			Text(L"LOAD GAME", 5 * 16 + 2, nScreenWidth / 2 - 4, 14);
			drawNotiBoard3(nScreenWidth / 2 - 6, 16, 12, 6);
			Text(L"SETTING", 5 * 16 + 2, nScreenWidth / 2 - 3, 17);
			drawNotiBoard3(nScreenWidth / 2 - 6, 19, 12, 6);
			Text(L"HELP", 5 * 16 + 2, nScreenWidth / 2 - 2, 20);
			drawNotiBoard3(nScreenWidth / 2 - 6, 22, 12, 6);
			Text(L"ABOUT", 5 * 16 + 2, nScreenWidth / 2 - 2, 23);
			drawNotiBoard3(nScreenWidth / 2 - 6, 25, 12, 6);
			Text(L"EXIT", 5 * 16 + 2, nScreenWidth / 2 - 2, 26);
			break;
		}
		case 2:
		{
			drawNotiBoard3(nScreenWidth / 2 - 6, 10, 12, 6);
			Text(L"NEW GAME", 5 * 16 + 2, nScreenWidth / 2 - 4, 11);
			drawNotiBoard3(nScreenWidth / 2 - 6, 13, 12, 6);
			Text(L"LOAD GAME", 5 * 16 + 6, nScreenWidth / 2 - 4, 14);
			drawNotiBoard3(nScreenWidth / 2 - 6, 16, 12, 6);
			Text(L"SETTING", 5 * 16 + 2, nScreenWidth / 2 - 3, 17);
			drawNotiBoard3(nScreenWidth / 2 - 6, 19, 12, 6);
			Text(L"HELP", 5 * 16 + 2, nScreenWidth / 2 - 2, 20);
			drawNotiBoard3(nScreenWidth / 2 - 6, 22, 12, 6);
			Text(L"ABOUT", 5 * 16 + 2, nScreenWidth / 2 - 2, 23);
			drawNotiBoard3(nScreenWidth / 2 - 6, 25, 12, 6);
			Text(L"EXIT", 5 * 16 + 2, nScreenWidth / 2 - 2, 26);
			break;
		}
		case 3:
		{
			drawNotiBoard3(nScreenWidth / 2 - 6, 10, 12, 6);
			Text(L"NEW GAME", 5 * 16 + 2, nScreenWidth / 2 - 4, 11);
			drawNotiBoard3(nScreenWidth / 2 - 6, 13, 12, 6);
			Text(L"LOAD GAME", 5 * 16 + 2, nScreenWidth / 2 - 4, 14);
			drawNotiBoard3(nScreenWidth / 2 - 6, 16, 12, 6);
			Text(L"SETTING", 5 * 16 + 6, nScreenWidth / 2 - 3, 17);
			drawNotiBoard3(nScreenWidth / 2 - 6, 19, 12, 6);
			Text(L"HELP", 5 * 16 + 2, nScreenWidth / 2 - 2, 20);
			drawNotiBoard3(nScreenWidth / 2 - 6, 22, 12, 6);
			Text(L"ABOUT", 5 * 16 + 2, nScreenWidth / 2 - 2, 23);
			drawNotiBoard3(nScreenWidth / 2 - 6, 25, 12, 6);
			Text(L"EXIT", 5 * 16 + 2, nScreenWidth / 2 - 2, 26);
			break;
		}
		case 4:
		{
			drawNotiBoard3(nScreenWidth / 2 - 6, 10, 12, 6);
			Text(L"NEW GAME", 5 * 16 + 2, nScreenWidth / 2 - 4, 11);
			drawNotiBoard3(nScreenWidth / 2 - 6, 13, 12, 6);
			Text(L"LOAD GAME", 5 * 16 + 2, nScreenWidth / 2 - 4, 14);
			drawNotiBoard3(nScreenWidth / 2 - 6, 16, 12, 6);
			Text(L"SETTING", 5 * 16 + 2, nScreenWidth / 2 - 3, 17);
			drawNotiBoard3(nScreenWidth / 2 - 6, 19, 12, 6);
			Text(L"HELP", 5 * 16 + 6, nScreenWidth / 2 - 2, 20);
			drawNotiBoard3(nScreenWidth / 2 - 6, 22, 12, 6);
			Text(L"ABOUT", 5 * 16 + 2, nScreenWidth / 2 - 2, 23);
			drawNotiBoard3(nScreenWidth / 2 - 6, 25, 12, 6);
			Text(L"EXIT", 5 * 16 + 2, nScreenWidth / 2 - 2, 26);
			break;
		}
		case 5:
		{
			drawNotiBoard3(nScreenWidth / 2 - 6, 10, 12, 6);
			Text(L"NEW GAME", 5 * 16 + 2, nScreenWidth / 2 - 4, 11);
			drawNotiBoard3(nScreenWidth / 2 - 6, 13, 12, 6);
			Text(L"LOAD GAME", 5 * 16 + 2, nScreenWidth / 2 - 4, 14);
			drawNotiBoard3(nScreenWidth / 2 - 6, 16, 12, 6);
			Text(L"SETTING", 5 * 16 + 2, nScreenWidth / 2 - 3, 17);
			drawNotiBoard3(nScreenWidth / 2 - 6, 19, 12, 6);
			Text(L"HELP", 5 * 16 + 2, nScreenWidth / 2 - 2, 20);
			drawNotiBoard3(nScreenWidth / 2 - 6, 22, 12, 6);
			Text(L"ABOUT", 5 * 16 + 6, nScreenWidth / 2 - 2, 23);
			drawNotiBoard3(nScreenWidth / 2 - 6, 25, 12, 6);
			Text(L"EXIT", 5 * 16 + 2, nScreenWidth / 2 - 2, 26);
			break;
		}
		case 6:
		{
			drawNotiBoard3(nScreenWidth / 2 - 6, 10, 12, 6);
			Text(L"NEW GAME", 5 * 16 + 2, nScreenWidth / 2 - 4, 11);
			drawNotiBoard3(nScreenWidth / 2 - 6, 13, 12, 6);
			Text(L"LOAD GAME", 5 * 16 + 2, nScreenWidth / 2 - 4, 14);
			drawNotiBoard3(nScreenWidth / 2 - 6, 16, 12, 6);
			Text(L"SETTING", 5 * 16 + 2, nScreenWidth / 2 - 3, 17);
			drawNotiBoard3(nScreenWidth / 2 - 6, 19, 12, 6);
			Text(L"HELP", 5 * 16 + 2, nScreenWidth / 2 - 2, 20);
			drawNotiBoard3(nScreenWidth / 2 - 6, 22, 12, 6);
			Text(L"ABOUT", 5 * 16 + 2, nScreenWidth / 2 - 2, 23);
			drawNotiBoard3(nScreenWidth / 2 - 6, 25, 12, 6);
			Text(L"EXIT", 5 * 16 + 6, nScreenWidth / 2 - 2, 26);
			break;
		}
		}
		// Hiển thị
		Display();
	}
}
void NewGamePage()
{
	ClearScreen(1, 0);
	Background();
	DrawObject(NewGame, 2 * 16 + 12, nScreenWidth / 2 - NewGame[0].length() / 2, 3);

	drawNotiBoard2(nScreenWidth / 2 - 8, 11, 16, 8);
	Text(L"1 PLAYER", 5 * 16 + 6, nScreenWidth / 2 - 4, 12);
	drawNotiBoard2(nScreenWidth / 2 - 8, 16, 16, 8);
	Text(L"2 PLAYERS", 5 * 16 + 2, nScreenWidth / 2 - 4, 17);
	drawNotiBoard2(nScreenWidth / 2 - 8, 21, 16, 8);
	Text(L"BACK", 5 * 16 + 2, nScreenWidth / 2 - 2, 22);

	Display();

	int nSelect = 1;
	while (1)
	{
		int move = toupper(_getch());

		if (move == 'S' || move == 80)
		{
			if (sound)
				playSound(4);

			nSelect++;
			if (nSelect > 3)
				nSelect -= 3;
		}
		if (move == 'W' || move == 72)
		{
			if (sound)
				playSound(4);

			nSelect--;
			if (nSelect < 1)
				nSelect += 3;
		}
		if (move == 13 || move == 32)
		{
			if (sound)
				playSound(0);

			if ((nSelect == 1 && PlaywCom(0, 0) != 1) ||
				(nSelect == 2 && PlaywHum(0) != 1) ||
				nSelect == 3)
			{
				ClearScreen(1, 0);
				Background();
				return;
			}
		}
		DrawObject(NewGame, 2 * 16 + 12, nScreenWidth / 2 - NewGame[0].length() / 2, 3);

		switch (nSelect)
		{
		case 1:
		{
			drawNotiBoard2(nScreenWidth / 2 - 8, 11, 16, 8);
			Text(L"1 PLAYER", 5 * 16 + 6, nScreenWidth / 2 - 4, 12);
			drawNotiBoard2(nScreenWidth / 2 - 8, 16, 16, 8);
			Text(L"2 PLAYERS", 5 * 16 + 2, nScreenWidth / 2 - 4, 17);
			drawNotiBoard2(nScreenWidth / 2 - 8, 21, 16, 8);
			Text(L"BACK", 5 * 16 + 2, nScreenWidth / 2 - 2, 22);
			break;
		}
		case 2:
		{
			drawNotiBoard2(nScreenWidth / 2 - 8, 11, 16, 8);
			Text(L"1 PLAYER", 5 * 16 + 2, nScreenWidth / 2 - 4, 12);
			drawNotiBoard2(nScreenWidth / 2 - 8, 16, 16, 8);
			Text(L"2 PLAYERS", 5 * 16 + 6, nScreenWidth / 2 - 4, 17);
			drawNotiBoard2(nScreenWidth / 2 - 8, 21, 16, 8);
			Text(L"BACK", 5 * 16 + 2, nScreenWidth / 2 - 2, 22);
			break;
		}
		case 3:
		{
			drawNotiBoard2(nScreenWidth / 2 - 8, 11, 16, 8);
			Text(L"1 PLAYER", 5 * 16 + 2, nScreenWidth / 2 - 4, 12);
			drawNotiBoard2(nScreenWidth / 2 - 8, 16, 16, 8);
			Text(L"2 PLAYERS", 5 * 16 + 2, nScreenWidth / 2 - 4, 17);
			drawNotiBoard2(nScreenWidth / 2 - 8, 21, 16, 8);
			Text(L"BACK", 5 * 16 + 6, nScreenWidth / 2 - 2, 22);
			break;
		}
		}
		// Hiển thị
		Display();
	}
}
void LoadGamePage()
{
	ClearScreen(1, 0);
	Backgroundsub();
	DrawObject(LoadGame, 2 * 16 + 7, nScreenWidth / 2 - LoadGame[0].length() / 2, 3);

	drawNotiBoard(31, 10, 40, 30);
	drawNotiBoard2(74, 11, 14, 6);
	drawNotiBoard2(74, 15, 14, 6);
	drawNotiBoard2(74, 19, 14, 6);
	drawNotiBoard2(74, 23, 14, 6);

	vector<wstring> listName = loadNamefile();
	int tab = 0;
	int soluong = (listName.size() <= 5) ? listName.size() : 5;
	if (listName.size() > 0)
	{
		Text(listName[0], 5 * 16 + 6, 42, 12);
		for (int i = 1; i < soluong; i++)
			Text(listName[i], 5 * 16 + 2, 42, 12 + 2 * i);
	}
	else
		Text(L"[Empty]", 5 * 16 + 2, 47, 12);

	Text(L"LOAD", 5 * 16 + 2, 79, 12);
	Text(L"RENAME", 5 * 16 + 2, 78, 16);
	Text(L"DELETE", 5 * 16 + 2, 78, 20);
	if (listName.size() <= 0)
		Text(L"BACK", 5 * 16 + 6, 79, 24);
	else
		Text(L"BACK", 5 * 16 + 2, 79, 24);

	Display();

	int nfile = 0, nSelect = 1;
	int side = 0;

	while (1)
	{
		soluong = (listName.size() - tab * 5 <= 5) ? (listName.size() - tab * 5) : 5;
		for (int n = 0; n < 6; n++)
			for (int i = 0; i < 22; i++)
				pBuffer[(12 + 2 * n) * nScreenWidth + 42 + i] = L' ';
		for (int i = 0; i < soluong; i++)
			Text(listName[i + tab * 5], 5 * 16 + 2, 42, 12 + 2 * i);


		int move = toupper(_getch());
		if (listName.size() <= 0)
		{
			nSelect = 4;
			side = 1;
		}
		else
		{
			if (move == 'S' || move == 80)
			{
				if (sound)
					playSound(4);

				if (side == 0)
				{
					if (listName.size() > 0)
					{
						if (nfile < listName.size() - 1)
							nfile++;
						else
							nfile = listName.size() - 1;
					}
					else
						nfile = 0;

					if (tab != nfile / 5)
					{
						for (int n = 0; n < 5; n++)
							for (int i = 0; i < 20; i++)
								pBuffer[(12 + 2 * n) * nScreenWidth + 42 + i] = L' ';

						tab = nfile / 5;
						soluong = (listName.size() - tab * 5 <= 5) ? (listName.size() - tab * 5) : 5;
						for (int i = 0; i < soluong; i++)
							Text(listName[i + 5 * tab], 5 * 16 + 2, 42, 12 + 2 * i);
					}
				}
				else
				{
					nSelect++;
					if (nSelect > 4)
						nSelect -= 4;
				}
			}
			if (move == 'W' || move == 72)
			{
				if (sound)
					playSound(4);

				if (side == 0)
				{
					if (listName.size() > 0)
					{
						if (nfile > 0)
							nfile--;
						else
							nfile = 0;
					}
					else
						nfile = 0;

					if (tab != nfile / 5)
					{
						for (int n = 0; n < 5; n++)
							for (int i = 0; i < 20; i++)
								pBuffer[(12 + 2 * n) * nScreenWidth + 42 + i] = L' ';

						tab = nfile / 5;
						soluong = (listName.size() - tab * 5 <= 5) ? (listName.size() - tab * 5) : 5;
						for (int i = 0; i < soluong; i++)
							Text(listName[i + 5 * tab], 5 * 16 + 2, 42, 12 + 2 * i);
					}
				}
				else
				{
					nSelect--;
					if (nSelect < 1)
						nSelect += 4;
				}
			}
			if (move == 'D' || move == 77 || move == 'A' || move == 75)
			{
				if (sound)
					playSound(4);

				side = (side != 1) ? 1 : 0;
			}
		}
		if (move == 13 || move == 32)
		{
			if (sound)
				playSound(0);

			if (side == 0)
			{
				side = 1;
				nSelect = 1;
			}
			else
			{
				switch (nSelect)
				{
				case 1:
				{
					int level{};
					idFile = nfile;
					loadDatafile(listName[nfile], level);
					if (level == -1)
						PlaywHum(1);
					else if (level >= 0)
						PlaywCom(1, level);
					ClearScreen(1, 0);
					Background();
					return;
				}
				case 2:
				{
					wstring wstrNamefile = L"FILE_" + int_to_wstr(rand());
					if (enterNameFile(pBuffer, pColor, wstrNamefile, L"FILE'S NAME", 44, 10))
					{
						char ch[20]{};

						const wchar_t* wch = wstrNamefile.c_str();
						size_t size = (wcslen(wch) + 1) * sizeof(wchar_t);

						wcstombs(ch, wch, size);
						renamefile(nfile, listName, ch);

						listName = loadNamefile();
						soluong = (listName.size() - tab * 5 <= 5) ? (listName.size() - tab * 5) : 5;
						for (int j = 42; j < 42 + 20; j++)
							pBuffer[(12 + 2 * (nfile % 5)) * nScreenWidth + j] = L' ';
						for (int i = 0; i < soluong; i++)
						{
							Text(listName[i + 5 * tab], 5 * 16 + 2, 42, 12 + 2 * i);
						}
					}
					break;
				}
				case 3:
					deletefile(nfile, listName);
					listName = loadNamefile();
					soluong = (listName.size() - tab * 5 <= 5) ? (listName.size() - tab * 5) : 5;
					if (nfile > 0)
						nfile--;

					for (int n = 0; n < 5; n++)
						for (int i = 0; i < 20; i++)
							pBuffer[(12 + 2 * n) * nScreenWidth + 42 + i] = L' ';
					for (int i = 0; i < soluong; i++)
						Text(listName[i + 5 * tab], 5 * 16 + 2, 42, 12 + 2 * i);
					if (sound)
						playSound(3);
					nSelect = 4;
					break;
				case 4:
					ClearScreen(1, 0);
					Background();
					return;
				}
			}
		}

		if (side == 0)
		{
			if (listName.size() > 0)
				Text(listName[nfile], 5 * 16 + 6, 42, 12 + 2 * (nfile % 5));
			else
				Text(L"[Empty]", 5 * 16 + 2, 47, 12);
			Text(L"LOAD", 5 * 16 + 2, 79, 12);
			Text(L"RENAME", 5 * 16 + 2, 78, 16);
			Text(L"DELETE", 5 * 16 + 2, 78, 20);
			Text(L"BACK", 5 * 16 + 2, 79, 24);
		}
		else
		{
			if (listName.size() <= 0)
				Text(L"[Empty]", 5 * 16 + 2, 47, 12);
			else
				Text(listName[nfile], 5 * 16 + 0, 42, 12 + 2 * (nfile % 5));

			switch (nSelect)
			{
			case 1:
				Text(L"LOAD", 5 * 16 + 6, 79, 12);
				Text(L"RENAME", 5 * 16 + 2, 78, 16);
				Text(L"DELETE", 5 * 16 + 2, 78, 20);
				Text(L"BACK", 5 * 16 + 2, 79, 24);
				break;
			case 2:
				Text(L"LOAD", 5 * 16 + 2, 79, 12);
				Text(L"RENAME", 5 * 16 + 6, 78, 16);
				Text(L"DELETE", 5 * 16 + 2, 78, 20);
				Text(L"BACK", 5 * 16 + 2, 79, 24);
				break;
			case 3:
				Text(L"LOAD", 5 * 16 + 2, 79, 12);
				Text(L"RENAME", 5 * 16 + 2, 78, 16);
				Text(L"DELETE", 5 * 16 + 6, 78, 20);
				Text(L"BACK", 5 * 16 + 2, 79, 24);
				break;
			case 4:
				Text(L"LOAD", 5 * 16 + 2, 79, 12);
				Text(L"RENAME", 5 * 16 + 2, 78, 16);
				Text(L"DELETE", 5 * 16 + 2, 78, 20);
				Text(L"BACK", 5 * 16 + 6, 79, 24);
				break;
			}
		}
		// Hiển thị
		Display();
	}
}
void AboutPage()
{
	ClearScreen(1, 0);
	Backgroundsub();

	DrawObject(About, 2 * 16 + 8, nScreenWidth / 2 - About[0].length() / 2, 3);
	drawNotiBoard(31, 10, nScreenWidth - 62, 30);

	Text(L"HCMUS - 22CLC01 - GROUP 7", 5 * 16 + 2, nScreenWidth / 2 - 11, 12);

	Text(L"<< TEACHER >>", 5 * 16 + 0, nScreenWidth / 2 - 5, 14);
	Text(L"Truong Toan Thinh", 5 * 16 + 2, nScreenWidth / 2 - 7, 15);

	Text(L"<< GROUP'S MEMBERS >>", 5 * 16 + 0, nScreenWidth / 2 - 9, 17);
	Text(L"22127029 - Le Nguyen Gia Bao", 5 * 16 + 2, nScreenWidth / 2 - 16, 18);
	Text(L"22127146 - Dinh Nguyen Quynh Huong", 5 * 16 + 2, nScreenWidth / 2 - 16, 19);
	Text(L"22127435 - Vo Le Viet Tu", 5 * 16 + 2, nScreenWidth / 2 - 16, 20);
	Text(L"22127446 - Nguyen Ngoc Phuong Uyen", 5 * 16 + 2, nScreenWidth / 2 - 16, 21);

	Text(L"BACK", 5 * 16 + 6, nScreenWidth / 2 - 1, 23);

	Display();
	_getch();
	if (sound)
		playSound(0);

	ClearScreen(1, 0);
	Background();
}

void SettingPage(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY)
{
	if (music)
		PlaySound(nullptr, nullptr, 0);

	WORD* pTmpColor = new WORD[nScreenWidth * nScreenHeight];
	wchar_t* pTmpBuffer = new wchar_t[nScreenWidth * nScreenHeight];

	for (int i = 0; i < nScreenHeight; i++)
		for (int j = 0; j < nScreenWidth; j++)
		{
			pTmpBuffer[i * nScreenWidth + j] = pBuffer[i * nScreenWidth + j];
			pTmpColor[i * nScreenWidth + j] = pColor[i * nScreenWidth + j];
		}
	drawNotiBoard(pTmpBuffer, pTmpColor, fromX, fromY, 30, 15);
	Text(pTmpBuffer, pTmpColor, L"MUSIC:", 16 * 5 + 6, fromX + 4, fromY + 2);
	Text(pTmpBuffer, pTmpColor, L"/", 16 * 5 + 2, fromX + 21, fromY + 2);
	if (music)
	{
		Text(pTmpBuffer, pTmpColor, L"ON", 16 * 5 + 6, fromX + 18, fromY + 2);
		Text(pTmpBuffer, pTmpColor, L"OFF", 16 * 5 + 2, fromX + 23, fromY + 2);
	}
	else
	{
		Text(pTmpBuffer, pTmpColor, L"ON", 16 * 5 + 2, fromX + 18, fromY + 2);
		Text(pTmpBuffer, pTmpColor, L"OFF", 16 * 5 + 6, fromX + 23, fromY + 2);
	}

	Text(pTmpBuffer, pTmpColor, L"SOUND:", 16 * 5 + 2, fromX + 4, fromY + 4);
	Text(pTmpBuffer, pTmpColor, L"/", 16 * 5 + 2, fromX + 21, fromY + 4);
	if (sound)
	{
		Text(pTmpBuffer, pTmpColor, L"ON", 16 * 5 + 6, fromX + 18, fromY + 4);
		Text(pTmpBuffer, pTmpColor, L"OFF", 16 * 5 + 2, fromX + 23, fromY + 4);
	}
	else
	{
		Text(pTmpBuffer, pTmpColor, L"ON", 16 * 5 + 2, fromX + 18, fromY + 4);
		Text(pTmpBuffer, pTmpColor, L"OFF", 16 * 5 + 6, fromX + 23, fromY + 4);
	}

	Text(pTmpBuffer, pTmpColor, L"BACK", 5 * 16 + 2, fromX + 13, fromY + 6);

	Display(pTmpBuffer, pTmpColor, 0, 0, nScreenWidth - 1, nScreenHeight - 1);

	int nSelect = 1;
	while (1)
	{
		int move = toupper(_getch());
		if (move == 'S' || move == 80)
		{
			if (sound)
				playSound(4);

			nSelect++;
			if (nSelect > 3)
				nSelect -= 3;
		}
		if (move == 'W' || move == 72)
		{
			if (sound)
				playSound(4);

			nSelect--;
			if (nSelect < 1)
				nSelect += 3;
		}

		if (move == 13 || move == 32)
		{
			if (sound)
				playSound(0);

			switch (nSelect)
			{
			case 1:
				music = (music) ? false : true;
				break;
			case 2:
				sound = (sound) ? false : true;
				break;
			case 3:
				if (music)
					PlaySound(TEXT("main_music.wav"), NULL, SND_FILENAME | SND_LOOP | SND_ASYNC);

				delete[] pTmpBuffer;
				delete[] pTmpColor;
				return;
			}
		}

		if (music)
		{
			Text(pTmpBuffer, pTmpColor, L"ON", 16 * 5 + 6, fromX + 18, fromY + 2);
			Text(pTmpBuffer, pTmpColor, L"OFF", 16 * 5 + 2, fromX + 23, fromY + 2);
		}
		else
		{
			Text(pTmpBuffer, pTmpColor, L"ON", 16 * 5 + 2, fromX + 18, fromY + 2);
			Text(pTmpBuffer, pTmpColor, L"OFF", 16 * 5 + 6, fromX + 23, fromY + 2);
		}
		if (sound)
		{
			Text(pTmpBuffer, pTmpColor, L"ON", 16 * 5 + 6, fromX + 18, fromY + 4);
			Text(pTmpBuffer, pTmpColor, L"OFF", 16 * 5 + 2, fromX + 23, fromY + 4);
		}
		else
		{
			Text(pTmpBuffer, pTmpColor, L"ON", 16 * 5 + 2, fromX + 18, fromY + 4);
			Text(pTmpBuffer, pTmpColor, L"OFF", 16 * 5 + 6, fromX + 23, fromY + 4);
		}

		switch (nSelect)
		{
		case 1:
			Text(pTmpBuffer, pTmpColor, L"MUSIC:", 16 * 5 + 6, fromX + 4, fromY + 2);
			Text(pTmpBuffer, pTmpColor, L"SOUND:", 16 * 5 + 2, fromX + 4, fromY + 4);
			Text(pTmpBuffer, pTmpColor, L"BACK", 5 * 16 + 2, fromX + 13, fromY + 6);
			break;
		case 2:
			Text(pTmpBuffer, pTmpColor, L"MUSIC:", 16 * 5 + 2, fromX + 4, fromY + 2);
			Text(pTmpBuffer, pTmpColor, L"SOUND:", 16 * 5 + 6, fromX + 4, fromY + 4);
			Text(pTmpBuffer, pTmpColor, L"BACK", 5 * 16 + 2, fromX + 13, fromY + 6);
			break;
		case 3:
			Text(pTmpBuffer, pTmpColor, L"MUSIC:", 16 * 5 + 2, fromX + 4, fromY + 2);
			Text(pTmpBuffer, pTmpColor, L"SOUND:", 16 * 5 + 2, fromX + 4, fromY + 4);
			Text(pTmpBuffer, pTmpColor, L"BACK", 5 * 16 + 6, fromX + 13, fromY + 6);
			break;
		}
		// Hiển thị
		Display(pTmpBuffer, pTmpColor, fromX, fromY, fromX + 30, fromY + 15);
	}
}
void HelpPage(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY)
{
	WORD* pTmpColor = new WORD[nScreenWidth * nScreenHeight];
	wchar_t* pTmpBuffer = new wchar_t[nScreenWidth * nScreenHeight];

	for (int i = 0; i < nScreenHeight; i++)
		for (int j = 0; j < nScreenWidth; j++)
		{
			pTmpBuffer[i * nScreenWidth + j] = pBuffer[i * nScreenWidth + j];
			pTmpColor[i * nScreenWidth + j] = pColor[i * nScreenWidth + j];
		}
	int width = 52;	//heigth = 30
	int realheight = 30 / 2;

	//Phan chu nhat o giua 
	for (int i = fromY + 3; i <= fromY + realheight - 2; i++)
		for (int j = fromX + 1; j <= fromX + width - 1; j++)
		{
			pTmpBuffer[i * nScreenWidth + j] = L' ';
			pTmpColor[i * nScreenWidth + j] = 5 * 16;
		}

	for (int i = fromY + 3; i <= fromY + realheight - 2; i++)
	{
		pTmpBuffer[i * nScreenWidth + fromX] = L' ';
		pTmpColor[i * nScreenWidth + fromX] = 4 * 16;
	}

	for (int i = fromY + 3; i <= fromY + realheight - 2; i++)
	{
		pTmpBuffer[i * nScreenWidth + fromX + width] = L' ';
		pTmpColor[i * nScreenWidth + fromX + width] = 4 * 16;
	}

	for (int i = fromX + 1; i <= fromX + width - 1; i++)
	{
		pTmpBuffer[(fromY + 2) * nScreenWidth + i] = L'▀';
		pTmpColor[(fromY + 2) * nScreenWidth + i] = 5 * 16 + 4;
	}

	pTmpBuffer[(fromY + 2) * nScreenWidth + fromX] = L' ';
	pTmpColor[(fromY + 2) * nScreenWidth + fromX] = 4 * 16 + 4;

	pTmpBuffer[(fromY + 2) * nScreenWidth + fromX + width] = L' ';
	pTmpColor[(fromY + 2) * nScreenWidth + fromX + width] = 4 * 16 + 4;


	//Phan bo goc duoi 
	for (int i = fromX + 2; i <= fromX + width - 2; i++)
	{
		pTmpBuffer[(fromY + realheight - 1) * nScreenWidth + i] = L' ';
		pTmpColor[(fromY + realheight - 1) * nScreenWidth + i] = 5 * 16;
	}

	pTmpBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + 1] = L'▀';
	pTmpColor[(fromY + realheight - 1) * nScreenWidth + fromX + 1] = (pTmpColor[(fromY + realheight - 1) * nScreenWidth + fromX + 1] / 16) * 16 + 4;

	pTmpBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] = L'▀';
	pTmpColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] = (pTmpColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] / 16) * 16 + 4;

	pTmpBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + 2] = L'▄';
	pTmpColor[(fromY + realheight - 1) * nScreenWidth + fromX + 2] = (pTmpColor[(fromY + realheight - 1) * nScreenWidth + fromX + 2] / 16) * 16 + 4;

	pTmpBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + width - 2] = L'▄';
	pTmpColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 2] = (pTmpColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 2] / 16) * 16 + 4;

	for (int i = fromX + 4; i <= fromX + width - 4; i++)
	{
		pTmpBuffer[(fromY + realheight) * nScreenWidth + i] = L'▄';
		pTmpColor[(fromY + realheight) * nScreenWidth + i] = 5 * 16 + 4;
	}

	pTmpBuffer[(fromY + realheight) * nScreenWidth + fromX + 3] = L'▀';
	pTmpColor[(fromY + realheight) * nScreenWidth + fromX + 3] = (pTmpColor[(fromY + realheight) * nScreenWidth + fromX + 3] / 16) * 16 + 4;

	pTmpBuffer[(fromY + realheight) * nScreenWidth + fromX + width - 3] = L'▀';
	pTmpColor[(fromY + realheight) * nScreenWidth + fromX + width - 3] = (pTmpColor[(fromY + realheight) * nScreenWidth + fromX + width - 3] / 16) * 16 + 4;

	//Ve cac tab
	DrawTab(pTmpBuffer, pTmpColor, fromX, fromY, 20, L"Keyboard Guide");

	DrawTab(pTmpBuffer, pTmpColor, fromX + 20, fromY, 20, L"Rule");

	Text(pTmpBuffer, pTmpColor, L"BACK", 5 * 16 + 6, fromX + width / 2 - 2, fromY + realheight - 1);

	//Mac dinh ban dau la tab keyboard guide 
	KeyboardGuide(pTmpBuffer, pTmpColor, fromX, fromY, 20);
	//Viet noi dung tab keyboard guide
	Text(pTmpBuffer, pTmpColor, L"Player 1:", 5 * 16 + 2, fromX + 3, fromY + 5);
	Text(pTmpBuffer, pTmpColor, L"'W': Go up", 5 * 16 + 2, fromX + 3, fromY + 6);
	Text(pTmpBuffer, pTmpColor, L"'A': Go left", 5 * 16 + 2, fromX + 3, fromY + 7);
	Text(pTmpBuffer, pTmpColor, L"'S': Go down", 5 * 16 + 2, fromX + 3, fromY + 8);
	Text(pTmpBuffer, pTmpColor, L"'D': Go right ", 5 * 16 + 2, fromX + 3, fromY + 9);
	Text(pTmpBuffer, pTmpColor, L"'SPACE': Mark", 5 * 16 + 2, fromX + 3, fromY + 10);

	Text(pTmpBuffer, pTmpColor, L"Player 2:", 5 * 16 + 2, fromX + 21, fromY + 5);
	Text(pTmpBuffer, pTmpColor, L"'↑': Go up", 5 * 16 + 2, fromX + 21, fromY + 6);
	Text(pTmpBuffer, pTmpColor, L"'←': Go left", 5 * 16 + 2, fromX + 21, fromY + 7);
	Text(pTmpBuffer, pTmpColor, L"'↓': Go down", 5 * 16 + 2, fromX + 21, fromY + 8);
	Text(pTmpBuffer, pTmpColor, L"'→': Go right ", 5 * 16 + 2, fromX + 21, fromY + 9);
	Text(pTmpBuffer, pTmpColor, L"'ENTER': Mark", 5 * 16 + 2, fromX + 21, fromY + 10);

	Text(pTmpBuffer, pTmpColor, L"'U': Undo", 5 * 16 + 2, fromX + 39, fromY + 5);
	Text(pTmpBuffer, pTmpColor, L"'esc': Pause", 5 * 16 + 2, fromX + 39, fromY + 6);

	Display(pTmpBuffer, pTmpColor, 0, 0, nScreenWidth - 1, nScreenHeight - 1);

	int nSelect = 1;
	while (1)
	{
		int move = toupper(_getch());

		if (move == 'D' || move == 77 || move == 'A' || move == 75)
		{
			if (sound)
				playSound(4);

			nSelect = (nSelect != 1) ? 1 : 2;
		}

		if (move == 13 || move == 32)
		{
			if (sound)
				playSound(0);

			delete[] pTmpBuffer;
			delete[] pTmpColor;
			return;
		}

		if (nSelect == 1)
		{
			//Vien tab keyboard guide, xoa vien tab rule
			KeyboardGuide(pTmpBuffer, pTmpColor, fromX, fromY, 20);
			//Xoa noi dung truoc do
			for (int i = fromY + 3; i <= fromY + realheight - 2; i++)
				for (int j = fromX + 1; j <= fromX + width - 1; j++)
					pTmpBuffer[i * nScreenWidth + j] = ' ';
			//Viet noi dung tab keyboard guide
			Text(pTmpBuffer, pTmpColor, L"Player 1:", 5 * 16 + 2, fromX + 3, fromY + 5);
			Text(pTmpBuffer, pTmpColor, L"'W': Go up", 5 * 16 + 2, fromX + 3, fromY + 6);
			Text(pTmpBuffer, pTmpColor, L"'A': Go left", 5 * 16 + 2, fromX + 3, fromY + 7);
			Text(pTmpBuffer, pTmpColor, L"'S': Go down", 5 * 16 + 2, fromX + 3, fromY + 8);
			Text(pTmpBuffer, pTmpColor, L"'D': Go right ", 5 * 16 + 2, fromX + 3, fromY + 9);
			Text(pTmpBuffer, pTmpColor, L"'SPACE': Mark", 5 * 16 + 2, fromX + 3, fromY + 10);

			Text(pTmpBuffer, pTmpColor, L"Player 2:", 5 * 16 + 2, fromX + 21, fromY + 5);
			Text(pTmpBuffer, pTmpColor, L"'↑': Go up", 5 * 16 + 2, fromX + 21, fromY + 6);
			Text(pTmpBuffer, pTmpColor, L"'←': Go left", 5 * 16 + 2, fromX + 21, fromY + 7);
			Text(pTmpBuffer, pTmpColor, L"'↓': Go down", 5 * 16 + 2, fromX + 21, fromY + 8);
			Text(pTmpBuffer, pTmpColor, L"'→': Go right ", 5 * 16 + 2, fromX + 21, fromY + 9);
			Text(pTmpBuffer, pTmpColor, L"'ENTER': Mark", 5 * 16 + 2, fromX + 21, fromY + 10);

			Text(pTmpBuffer, pTmpColor, L"'U': Undo", 5 * 16 + 2, fromX + 39, fromY + 5);
			Text(pTmpBuffer, pTmpColor, L"'esc': Pause", 5 * 16 + 2, fromX + 39, fromY + 6);
		}
		else
		{
			//Vient tab rule, xoa vien tab keyboard guide 
			Rule(pTmpBuffer, pTmpColor, fromX + 20, fromY, 20);
			//Xoa noi dung truoc do
			for (int i = fromY + 3; i <= fromY + realheight - 2; i++)
				for (int j = fromX + 1; j <= fromX + width - 1; j++)
					pTmpBuffer[i * nScreenWidth + j] = ' ';
			//Viet noi dung tab rule
			Text(pTmpBuffer, pTmpColor, L"Players alternate turns putting their marks on an", 5 * 16 + 2, fromX + 2, fromY + 4);
			Text(pTmpBuffer, pTmpColor, L"empty intersection. X plays first. The winner is", 5 * 16 + 2, fromX + 2, fromY + 5);
			Text(pTmpBuffer, pTmpColor, L"the first player to form an unbroken line of 5", 5 * 16 + 2, fromX + 2, fromY + 6);
			Text(pTmpBuffer, pTmpColor, L"marks horizontally, vertically, or diagonally.", 5 * 16 + 2, fromX + 2, fromY + 7);

			Text(pTmpBuffer, pTmpColor, L"If the board is completely filled and no one can", 5 * 16 + 2, fromX + 2, fromY + 9);
			Text(pTmpBuffer, pTmpColor, L"make a line of 5 marks, then it will result in", 5 * 16 + 2, fromX + 2, fromY + 10);
			Text(pTmpBuffer, pTmpColor, L"a draw.", 5 * 16 + 2, fromX + 2, fromY + 11);


		}

		// Hiển thị
		Display(pTmpBuffer, pTmpColor, fromX, fromY, fromX + width - 1, fromY + 29);
	}
}
void ExitPage()
{
	if (music)
		PlaySound(nullptr, nullptr, 0);

	ClearScreen(1, 0);
	Background();
	DrawObject(Exit, 2 * 16 + 14, nScreenWidth / 2 - Exit[0].length() / 2 + 1, 5);

	drawNotiBoard(44, 13, 30, 15);
	Text(L"Do you really want to exit?", 16 * 5 + 2, 46, 15);
	Text(L"YES", 16 * 5 + 2, 50, 18);
	Text(L"NO", 16 * 5 + 6, 65, 18);
	Text(L"|", 5 * 16 + 4, 59, 18);

	Display();

	int nSelect = 2;
	while (1)
	{
		int move = toupper(_getch());

		if (move == 'D' || move == 77 || move == 'A' || move == 75)
		{
			if (sound)
				playSound(4);

			nSelect = (nSelect != 1) ? 1 : 2;
		}

		if (move == 13 || move == 32)
		{
			if (sound)
				playSound(0);

			if (nSelect == 1)
			{
				if (sound)
					playSound(3);
				Sleep(2000);

				delete[] pBuffer;
				delete[] pColor;
				ShowCur(1);
				ShowScrollbar(1);
				system("Mode 120, 9001");
				exit(0);
			}
			if (nSelect == 2)
			{
				if (music)
					PlaySound(TEXT("main_music.wav"), NULL, SND_FILENAME | SND_LOOP | SND_ASYNC);

				ClearScreen(1, 0);
				Background();
				return;
			}
			return;
		}

		switch (nSelect)
		{
		case 1:
			Text(L"YES", 16 * 5 + 6, 50, 18);
			Text(L"NO", 16 * 5 + 2, 65, 18);
			break;
		case 2:
			Text(L"YES", 16 * 5 + 2, 50, 18);
			Text(L"NO", 16 * 5 + 6, 65, 18);
			break;
		}
		// Hiển thị
		Display();
	}
}

