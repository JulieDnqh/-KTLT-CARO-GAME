﻿#pragma once
#include "Global.h"
#include "Model.h"
#include "Control.h"
using namespace std;

void DisableResizeWindow();
void ShowScrollbar(BOOL Show);
void ShowCur(bool CursorVisibility);

//hàm cấu hình, thiết lập kích thước console và thay đổi bảng màu
void Configure();

//hàm hiển thị kí tự và màu sắc từ các con trỏ
void Display(int fromX = 0, int fromY = 0, int toX = nScreenWidth - 1, int toY = nScreenHeight - 1);
void Display(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int toX, int toY);

void ClearScreen(int background, int text);
void Text(wstring wsContent, WORD wColor, int nPosX, int nPosY);
void Text(wchar_t* pBuffer, WORD* pColor, wstring wsContent, WORD wColor, int nPosX, int nPosY);

void DrawObject(vector<wstring> wsContent, WORD wColor, int nPosX, int nPosY);
void DrawObject(wchar_t* pBuffer, WORD* pColor, vector<wstring> wsContent, WORD wColor, int nPosX, int nPosY);

void Board(int width, int height, int first_x, int first_y);
void Frame(int width, int height, int first_x, int first_y, wstring wsCaption);

void drawGrass(int fromX, int fromY);
void drawCloud(int fromX, int fromY);
void drawTree(int fromX, int fromY);
void drawBushes(int fromX, int fromY);
void drawWease(int fromX, int fromY);
void drawFox(int fromX, int fromY);

void drawNotiBoard(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width, int height);
void drawNotiBoard2(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width, int height);
void drawNotiBoard(int fromX, int fromY, int width, int height);
void drawNotiBoard2(int fromX, int fromY, int width, int height);
void drawNotiBoard3(int fromX, int fromY, int width, int height);
void drawEnterNameBoard(wstring title, int fromX, int fromY, int width, int height);

//vẽ nền
void Background();
void BackgroundOngame();
void Backgroundsub();

void printMatrix();

void Rule(wchar_t* pBuffer, WORD* pColor);
void KeyboardGuide(wchar_t* pBuffer, WORD* pColor);

void DrawTab(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width, wstring title);
void ColorTabFrame(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width, WORD color);
void KeyboardGuide(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width);
void Rule(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width);

void Blinking(vector<wstring> wsContent, int color1, int color2, int color3, int fromX, int fromY);
void Blinking(wchar_t* pBuffer, WORD* pColor, vector<wstring> wsContent, int color1, int color2, int color3, int fromX, int fromY);


