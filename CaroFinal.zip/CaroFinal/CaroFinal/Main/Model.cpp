﻿#include "Model.h"
using namespace std;

int enterName(wchar_t* pBuffer, WORD* pColor, wstring& name, wstring title, int fromX, int fromY)
{
	WORD* pTmpColor = new WORD[nScreenWidth * nScreenHeight];
	wchar_t* pTmpBuffer = new wchar_t[nScreenWidth * nScreenHeight];

	for (int i = fromY; i <= fromY + 15; i++)
		for (int j = fromX; j <= fromX + 30; j++)
		{
			pTmpBuffer[i * nScreenWidth + j] = pBuffer[i * nScreenWidth + j];
			pTmpColor[i * nScreenWidth + j] = pColor[i * nScreenWidth + j];
		}

	drawNotiBoard(pTmpBuffer, pTmpColor, fromX, fromY, 30, 15);
	Text(pTmpBuffer, pTmpColor, title, 5 * 16 + 2, fromX + 15 - title.length() / 2, fromY + 1);
	Text(pTmpBuffer, pTmpColor, L"Enter: ", 5 * 16 + 6, fromX + 1, fromY + 4);
	Text(pTmpBuffer, pTmpColor, L"OK", 16 * 5 + 2, fromX + 9, fromY + 6);
	Text(pTmpBuffer, pTmpColor, L"BACK", 16 * 5 + 2, fromX + 20, fromY + 6);
	Text(pTmpBuffer, pTmpColor, L"|", 5 * 16 + 4, fromX + 15, fromY + 6);
	Display(pTmpBuffer, pTmpColor, fromX, fromY, fromX + 30, fromY + 15);

	wstring temp = name;
	int nSelect = 1;
	int selectRL = 1;
	while (1)
	{
		int move = toupper(_getch());

		if (move == 'S' || move == 80 || move == 'W' || move == 72)
		{
			if (sound)
				playSound(4);

			nSelect = (nSelect != 1) ? 1 : 2;
		}
		if ((move == 'A' || move == 77 || move == 'D' || move == 75) && nSelect == 2)
		{
			if (sound)
				playSound(4);

			selectRL = (selectRL != 1) ? 1 : 2;
		}

		if (move == 13 || move == 32)
		{
			if (sound)
				playSound(0);

			if (nSelect == 1)
			{
				do
				{
					temp.clear();
					gotoXY(fromX + 8, fromY + 4);
					for (int i = fromX + 8; i < fromX + 8 + 20; i++)
						pTmpBuffer[(fromY + 4) * nScreenWidth + i] = L' ';
					if (temp[0] == ' ')
						Text(pTmpBuffer, pTmpColor, L"Cannot begin with space!", 5 * 16 + 2, fromX + 1, fromY + 3);
					else
						Text(pTmpBuffer, pTmpColor, L"*Less than 20 characters", 5 * 16 + 2, fromX + 1, fromY + 3);

					Display(pTmpBuffer, pTmpColor, fromX, fromY, fromX + 30, fromY + 15);

					char ch{}; int i = 0;
					ShowCur(1);
					while (1)
					{
						ch = _getch();

						//enter -> break
						if (ch == 13)
							break;
						//pass backspace/delete
						if (ch == 8 && i > 0)
						{
							temp.pop_back();
							i--;
							pTmpBuffer[(fromY + 4) * nScreenWidth + fromX + 8 + i] = L' ';
							pTmpColor[(fromY + 4) * nScreenWidth + fromX + 8 + i] = 16 * 5 + 2;
						}
						else if (ch >= 32 && ch <= 126 && i < 20)
						{
							temp.push_back(ch);
							pTmpBuffer[(fromY + 4) * nScreenWidth + fromX + 8 + i] = wchar_t(ch);
							pTmpColor[(fromY + 4) * nScreenWidth + fromX + 8 + i] = 16 * 5 + 6;
							i++;
						}
						gotoXY(fromX + 8 + i, fromY + 4);
						Display(pTmpBuffer, pTmpColor, fromX, fromY, fromX + 30, fromY + 15);
					}
				} while (temp[0] == L' ' || temp.size() <= 0);
				ShowCur(0);

				for (int i = 0; i < 24; i++)
					pTmpBuffer[(fromY + 3) * nScreenWidth + i + (fromX + 1)] = L' ';
				Display(pTmpBuffer, pTmpColor, fromX, fromY, fromX + 30, fromY + 15);
				nSelect++;
			}
			else
			{
				if (selectRL == 1)
				{
					name = temp;
					delete[] pTmpBuffer;
					delete[] pTmpColor;
					return 1;
				}
				else
				{
					delete[] pTmpBuffer;
					delete[] pTmpColor;
					return 0;
				}
			}
		}

		if (nSelect == 1)
		{
			Text(pTmpBuffer, pTmpColor, L"Enter: ", 5 * 16 + 6, fromX + 1, fromY + 4);
			Text(pTmpBuffer, pTmpColor, temp, 5 * 16 + 6, fromX + 8, fromY + 4);
			Text(pTmpBuffer, pTmpColor, L"OK", 16 * 5 + 2, fromX + 9, fromY + 6);
			Text(pTmpBuffer, pTmpColor, L"BACK", 16 * 5 + 2, fromX + 20, fromY + 6);
		}
		else
		{
			if (selectRL == 1)
			{
				Text(pTmpBuffer, pTmpColor, L"Enter: ", 5 * 16 + 2, fromX + 1, fromY + 4);
				Text(pTmpBuffer, pTmpColor, temp, 5 * 16 + 2, fromX + 8, fromY + 4);
				Text(pTmpBuffer, pTmpColor, L"OK", 16 * 5 + 6, fromX + 9, fromY + 6);
				Text(pTmpBuffer, pTmpColor, L"BACK", 16 * 5 + 2, fromX + 20, fromY + 6);
			}
			else
			{
				Text(pTmpBuffer, pTmpColor, L"Enter: ", 5 * 16 + 2, fromX + 1, fromY + 4);
				Text(pTmpBuffer, pTmpColor, temp, 5 * 16 + 2, fromX + 8, fromY + 4);
				Text(pTmpBuffer, pTmpColor, L"OK", 16 * 5 + 2, fromX + 9, fromY + 6);
				Text(pTmpBuffer, pTmpColor, L"BACK", 16 * 5 + 6, fromX + 20, fromY + 6);
			}
		}
		Display(pTmpBuffer, pTmpColor, fromX, fromY, fromX + 30, fromY + 15);
	}
}
bool checkInWstr(wstring wstr, vector<wstring> list)
{
	for (int i = 0; i < list.size(); i++)
		if (list[i] == wstr)
			return true;
	return false;
}
int enterNameFile(wchar_t* pBuffer, WORD* pColor, wstring& name, wstring title, int fromX, int fromY)
{
	WORD* pTmpColor = new WORD[nScreenWidth * nScreenHeight];
	wchar_t* pTmpBuffer = new wchar_t[nScreenWidth * nScreenHeight];

	for (int i = fromY; i <= fromY + 16; i++)
		for (int j = fromX; j <= fromX + 30; j++)
		{
			pTmpBuffer[i * nScreenWidth + j] = pBuffer[i * nScreenWidth + j];
			pTmpColor[i * nScreenWidth + j] = pColor[i * nScreenWidth + j];
		}

	drawNotiBoard(pTmpBuffer, pTmpColor, fromX, fromY, 30, 15);
	Text(pTmpBuffer, pTmpColor, title, 5 * 16 + 2, fromX + 15 - title.length() / 2, fromY + 1);
	Text(pTmpBuffer, pTmpColor, L"Enter: ", 5 * 16 + 6, fromX + 1, fromY + 4);
	Text(pTmpBuffer, pTmpColor, L"OK", 16 * 5 + 2, fromX + 9, fromY + 6);
	Text(pTmpBuffer, pTmpColor, L"BACK", 16 * 5 + 2, fromX + 20, fromY + 6);
	Text(pTmpBuffer, pTmpColor, L"|", 5 * 16 + 4, fromX + 15, fromY + 6);
	Display(pTmpBuffer, pTmpColor, fromX, fromY, fromX + 30, fromY + 16);

	wstring temp = name;
	vector<wstring> lstFile = loadNamefile();
	int nSelect = 1;
	int selectRL = 1;
	while (1)
	{
		int move = toupper(_getch());

		if (move == 'S' || move == 80 || move == 'W' || move == 72)
		{
			if (sound)
				playSound(4);

			nSelect = (nSelect != 1) ? 1 : 2;
		}
		if ((move == 'A' || move == 77 || move == 'D' || move == 75) && nSelect == 2)
		{
			if (sound)
				playSound(4);

			selectRL = (selectRL != 1) ? 1 : 2;
		}

		if (move == 13 || move == 32)
		{
			if (sound)
				playSound(0);

			if (nSelect == 1)
			{
				do
				{
					gotoXY(fromX + 8, fromY + 4);
					for (int i = fromX + 8; i < fromX + 8 + 20; i++)
						pTmpBuffer[(fromY + 4) * nScreenWidth + i] = L' ';

					if (temp[0] == L' ')
						Text(pTmpBuffer, pTmpColor, L"Cannot begin with space!", 5 * 16 + 2, fromX + 1, fromY + 3);
					else if (checkInWstr(temp, lstFile))
						Text(pTmpBuffer, pTmpColor, L"File's name has existed!", 5 * 16 + 2, fromX + 1, fromY + 3);
					else
						Text(pTmpBuffer, pTmpColor, L"*Less than 20 characters", 5 * 16 + 2, fromX + 1, fromY + 3);

					Display(pTmpBuffer, pTmpColor, fromX, fromY, fromX + 30, fromY + 16);

					char ch{}; int i = 0;
					ShowCur(1);
					temp.clear();
					while (1)
					{
						ch = _getch();

						//enter -> break
						if (ch == 13)
							break;
						//pass backspace/delete
						if (ch == 8 && i > 0)
						{
							temp.pop_back();
							i--;
							pTmpBuffer[(fromY + 4) * nScreenWidth + fromX + 8 + i] = L' ';
							pTmpColor[(fromY + 4) * nScreenWidth + fromX + 8 + i] = 16 * 5 + 2;
						}
						else if (ch >= 32 && ch <= 126 && i < 20)
						{
							temp.push_back(ch);
							pTmpBuffer[(fromY + 4) * nScreenWidth + fromX + 8 + i] = wchar_t(ch);
							pTmpColor[(fromY + 4) * nScreenWidth + fromX + 8 + i] = 16 * 5 + 6;
							i++;
						}
						gotoXY(fromX + 8 + i, fromY + 4);
						Display(pTmpBuffer, pTmpColor, fromX, fromY, fromX + 30, fromY + 15);
					}
				} while (temp[0] == L' ' || checkInWstr(temp, lstFile) || temp.size() <= 0);
				ShowCur(0);

				for (int i = 0; i < 24; i++)
					pTmpBuffer[(fromY + 3) * nScreenWidth + i + (fromX + 1)] = L' ';
				Display(pTmpBuffer, pTmpColor, fromX, fromY, fromX + 30, fromY + 16);
				nSelect++;
			}
			else
			{
				if (selectRL == 1)
				{
					name = temp;
					delete[] pTmpBuffer;
					delete[] pTmpColor;
					return 1;
				}
				else
				{
					delete[] pTmpBuffer;
					delete[] pTmpColor;
					return 0;
				}
			}
		}

		if (nSelect == 1)
		{
			Text(pTmpBuffer, pTmpColor, L"Enter: ", 5 * 16 + 6, fromX + 1, fromY + 4);
			Text(pTmpBuffer, pTmpColor, temp, 5 * 16 + 6, fromX + 8, fromY + 4);
			Text(pTmpBuffer, pTmpColor, L"OK", 16 * 5 + 2, fromX + 9, fromY + 6);
			Text(pTmpBuffer, pTmpColor, L"BACK", 16 * 5 + 2, fromX + 20, fromY + 6);
		}
		else
		{
			if (selectRL == 1)
			{
				Text(pTmpBuffer, pTmpColor, L"Enter: ", 5 * 16 + 2, fromX + 1, fromY + 4);
				Text(pTmpBuffer, pTmpColor, temp, 5 * 16 + 2, fromX + 8, fromY + 4);
				Text(pTmpBuffer, pTmpColor, L"OK", 16 * 5 + 6, fromX + 9, fromY + 6);
				Text(pTmpBuffer, pTmpColor, L"BACK", 16 * 5 + 2, fromX + 20, fromY + 6);
			}
			else
			{
				Text(pTmpBuffer, pTmpColor, L"Enter: ", 5 * 16 + 2, fromX + 1, fromY + 4);
				Text(pTmpBuffer, pTmpColor, temp, 5 * 16 + 2, fromX + 8, fromY + 4);
				Text(pTmpBuffer, pTmpColor, L"OK", 16 * 5 + 2, fromX + 9, fromY + 6);
				Text(pTmpBuffer, pTmpColor, L"BACK", 16 * 5 + 6, fromX + 20, fromY + 6);
			}
		}
		Display(pTmpBuffer, pTmpColor, fromX, fromY, fromX + 30, fromY + 16);
	}
}
int save_game(wchar_t* pBuffer, WORD* pColor, int level, int switch_file)
{
	wstring NameFile = L"FILE_" + int_to_wstr(rand());
	if (!switch_file)
	{
		if (enterNameFile(pBuffer, pColor, NameFile, L"FILE'S NAME", 44, 10) == 0)
			return 0;
	}
	else
	{
		vector<wstring> lstFile = loadNamefile();
		NameFile = lstFile[idFile];
		deletefile(idFile, lstFile);
	}

	//wstring to char*
	char namefile[30]{};
	const wchar_t* wch = NameFile.c_str();
	size_t size = (wcslen(wch) + 1) * sizeof(wchar_t);
	wcstombs(namefile, wch, size);

	errno_t err = 0;
	//Ghi name file vào list
	FILE* infile = nullptr;
	err = fopen_s(&infile, "nameoffile.txt", "at");
	if (infile == NULL)
		return 0;

	fprintf(infile, "%s\n", namefile);
	fclose(infile);

	char nametxt[30];
	strcpy_s(nametxt, namefile);
	strcat_s(nametxt, ".txt");

	//Ghi data file vào namefile.txt
	FILE* output = nullptr;
	err = fopen_s(&output, nametxt, "wt");
	if (output == NULL)
		return 0;

	for (int i = 0; i < Player1.Name.size(); i++) {
		fprintf(output, "%c", Player1.Name[i]);
	}
	fprintf(output, "\n");

	fprintf(output, "%i\n", Player1.Wins);
	fprintf(output, "%i\n", Player1.Time);
	fprintf(output, "%i\n", Player1.Moves);

	for (int i = 0; i < Player2.Name.size(); i++) {
		fprintf(output, "%c", Player2.Name[i]);
	}
	fprintf(output, "\n");

	fprintf(output, "%i\n", Player2.Wins);
	fprintf(output, "%i\n", Player2.Time);
	fprintf(output, "%i\n", Player2.Moves);

	fprintf(output, "%i\n", level);

	fprintf(output, "%i\n", Round);
	fprintf(output, "%i\n", Move._X);
	fprintf(output, "%i\n", Move._Y);
	fprintf(output, "%i\n", Move.flag);
	fprintf(output, "%i\n", currentX);
	fprintf(output, "%i\n", currentY);
	//luu thong tin nguoi choi

	for (int j = 0; j < BOARD_SIZE; j++)
	{
		for (int i = 0; i < BOARD_SIZE; i++)
			fprintf(output, "%i\t", CARO_BOARD[i][j]);
		fprintf(output, "\n");
	}
	fclose(output);

	drawNotiBoard(44, 10, 30, 15);
	Text(L"FILE'S NAME", 5 * 16 + 2, 54, 11);
	Text(L"Enter: ", 5 * 16 + 2, 45, 14);
	Text(NameFile, 5 * 16 + 2, 52, 14);
	Text(L"OK", 16 * 5 + 2, 53, 16);
	Text(L"|", 5 * 16 + 4, 59, 16);
	Text(L"BACK", 16 * 5 + 2, 64, 16);
	Text(L"*Save file successfully", 5 * 16 + 6, 45, 13);
	Text(L"Press any key to continue!", 1 * 16 + 0, 46, 18);
	Display();
	_getch();
	if (sound)
		playSound(0);

	return 1;
}
int Pause(int level, int switch_file)
{
	ShowCur(0);
	int select = 1;
	// Tạo mảng màu độc lập

	WORD* pTmpColor = new WORD[nScreenWidth * nScreenHeight];
	wchar_t* pTmpBuffer = new wchar_t[nScreenWidth * nScreenHeight];

	for (int i = 0; i < nScreenHeight; i++)
		for (int j = 0; j < nScreenWidth; j++)
		{
			pTmpBuffer[i * nScreenWidth + j] = pBuffer[i * nScreenWidth + j];
			pTmpColor[i * nScreenWidth + j] = pColor[i * nScreenWidth + j];
		}

	for (int i = 0; i <= nScreenHeight - 1; i++)
		for (int j = nScreenWidth / 2 - 1; j <= nScreenWidth / 2; j++)
		{
			pTmpBuffer[i * nScreenWidth + j] = L' ';
			pTmpColor[i * nScreenWidth + j] = 5 * 16 + 5;
		}
	for (int i = 0; i <= nScreenHeight - 1; i++)
	{
		pTmpBuffer[i * nScreenWidth + nScreenWidth / 2 + 1] = L' ';
		pTmpColor[i * nScreenWidth + nScreenWidth / 2 + 1] = 4 * 16 + 4;
	}
	drawNotiBoard2(pTmpBuffer, pTmpColor, nScreenWidth / 2 - 13, 1, 26, 8);
	Text(pTmpBuffer, pTmpColor, L"G A M E  P A U S E", 5 * 16 + 2, nScreenWidth / 2 - 9, 2);

	drawNotiBoard2(pTmpBuffer, pTmpColor, nScreenWidth / 2 - 12, 6, 16, 8);
	drawNotiBoard2(pTmpBuffer, pTmpColor, nScreenWidth / 2 - 12, 13, 16, 8);
	drawNotiBoard2(pTmpBuffer, pTmpColor, nScreenWidth / 2 - 12, 20, 16, 8);
	drawNotiBoard2(pTmpBuffer, pTmpColor, nScreenWidth / 2 - 3, 9, 16, 8);
	drawNotiBoard2(pTmpBuffer, pTmpColor, nScreenWidth / 2 - 3, 16, 16, 8);
	drawNotiBoard2(pTmpBuffer, pTmpColor, nScreenWidth / 2 - 3, 23, 16, 8);

	Text(pTmpBuffer, pTmpColor, L"RESUME", 5 * 16 + 6, nScreenWidth / 2 - 7, 7);
	Text(pTmpBuffer, pTmpColor, L"RESTART", 5 * 16 + 2, nScreenWidth / 2 + 2, 10);
	Text(pTmpBuffer, pTmpColor, L"SAVE", 5 * 16 + 2, nScreenWidth / 2 - 6, 14);
	Text(pTmpBuffer, pTmpColor, L"SETTING", 5 * 16 + 2, nScreenWidth / 2 + 2, 17);
	Text(pTmpBuffer, pTmpColor, L"HELP", 5 * 16 + 2, nScreenWidth / 2 - 6, 21);
	Text(pTmpBuffer, pTmpColor, L"QUIT", 5 * 16 + 2, nScreenWidth / 2 + 3, 24);

	Display(pTmpBuffer, pTmpColor, 0, 0, nScreenWidth - 1, nScreenHeight - 1);

	while (1)
	{
		int pauseMove = toupper(_getch());

		if (pauseMove == 'S' || pauseMove == 80)
		{
			if (sound)
				playSound(4);

			select++;
			if (select > 6)
				select -= 6;
		}
		if (pauseMove == 'W' || pauseMove == 72)
		{
			if (sound)
				playSound(4);

			select--;
			if (select < 1)
				select += 6;
		}
		if (pauseMove == 13 || pauseMove == 32)
		{
			if (sound)
				playSound(0);

			if (select == 1)
			{
				Display();
				break;
			}

			switch (select)
			{
			case 2:
				delete[] pTmpColor;
				delete[] pTmpBuffer;
				return -2;
			case 3:
				if (save_game(pTmpBuffer, pTmpColor, level, switch_file) == 1)
				{
					delete[] pTmpColor;
					delete[] pTmpBuffer;
					Player1.Moves = 0;
					Player1.Time = 0;
					Player1.Wins = 0;
					Player1.Name = L"";
					Player2.Moves = 0;
					Player2.Time = 0;
					Player2.Wins = 0;
					Player2.Name = L"";
					return -3;
				}
				break;
			case 4:
				SettingPage(pTmpBuffer, pTmpColor, 44, 10);
				break;
			case 5:
				HelpPage(pTmpBuffer, pTmpColor, nScreenWidth / 2 - 26, 6);
				break;
			case 6:
			{
				delete[] pTmpColor;
				delete[] pTmpBuffer;
				Player1.Moves = 0;
				Player1.Time = 0;
				Player1.Wins = 0;
				Player1.Name = L"";
				Player2.Moves = 0;
				Player2.Time = 0;
				Player2.Wins = 0;
				Player2.Name = L"";
				return -6;
			}
			}
		}
		switch (select)
		{
		case 1:
		{
			Text(pTmpBuffer, pTmpColor, L"RESUME", 5 * 16 + 6, nScreenWidth / 2 - 7, 7);
			Text(pTmpBuffer, pTmpColor, L"RESTART", 5 * 16 + 2, nScreenWidth / 2 + 2, 10);
			Text(pTmpBuffer, pTmpColor, L"SAVE", 5 * 16 + 2, nScreenWidth / 2 - 6, 14);
			Text(pTmpBuffer, pTmpColor, L"SETTING", 5 * 16 + 2, nScreenWidth / 2 + 2, 17);
			Text(pTmpBuffer, pTmpColor, L"HELP", 5 * 16 + 2, nScreenWidth / 2 - 6, 21);
			Text(pTmpBuffer, pTmpColor, L"QUIT", 5 * 16 + 2, nScreenWidth / 2 + 3, 24);
			break;
		}
		case 2:
		{
			Text(pTmpBuffer, pTmpColor, L"RESUME", 5 * 16 + 2, nScreenWidth / 2 - 7, 7);
			Text(pTmpBuffer, pTmpColor, L"RESTART", 5 * 16 + 6, nScreenWidth / 2 + 2, 10);
			Text(pTmpBuffer, pTmpColor, L"SAVE", 5 * 16 + 2, nScreenWidth / 2 - 6, 14);
			Text(pTmpBuffer, pTmpColor, L"SETTING", 5 * 16 + 2, nScreenWidth / 2 + 2, 17);
			Text(pTmpBuffer, pTmpColor, L"HELP", 5 * 16 + 2, nScreenWidth / 2 - 6, 21);
			Text(pTmpBuffer, pTmpColor, L"QUIT", 5 * 16 + 2, nScreenWidth / 2 + 3, 24);
			break;
		}
		case 3:
		{
			Text(pTmpBuffer, pTmpColor, L"RESUME", 5 * 16 + 2, nScreenWidth / 2 - 7, 7);
			Text(pTmpBuffer, pTmpColor, L"RESTART", 5 * 16 + 2, nScreenWidth / 2 + 2, 10);
			Text(pTmpBuffer, pTmpColor, L"SAVE", 5 * 16 + 6, nScreenWidth / 2 - 6, 14);
			Text(pTmpBuffer, pTmpColor, L"SETTING", 5 * 16 + 2, nScreenWidth / 2 + 2, 17);
			Text(pTmpBuffer, pTmpColor, L"HELP", 5 * 16 + 2, nScreenWidth / 2 - 6, 21);
			Text(pTmpBuffer, pTmpColor, L"QUIT", 5 * 16 + 2, nScreenWidth / 2 + 3, 24);
			break;
		}
		case 4:
		{
			Text(pTmpBuffer, pTmpColor, L"RESUME", 5 * 16 + 2, nScreenWidth / 2 - 7, 7);
			Text(pTmpBuffer, pTmpColor, L"RESTART", 5 * 16 + 2, nScreenWidth / 2 + 2, 10);
			Text(pTmpBuffer, pTmpColor, L"SAVE", 5 * 16 + 2, nScreenWidth / 2 - 6, 14);
			Text(pTmpBuffer, pTmpColor, L"SETTING", 5 * 16 + 6, nScreenWidth / 2 + 2, 17);
			Text(pTmpBuffer, pTmpColor, L"HELP", 5 * 16 + 2, nScreenWidth / 2 - 6, 21);
			Text(pTmpBuffer, pTmpColor, L"QUIT", 5 * 16 + 2, nScreenWidth / 2 + 3, 24);
			break;
		}
		case 5:
		{
			Text(pTmpBuffer, pTmpColor, L"RESUME", 5 * 16 + 2, nScreenWidth / 2 - 7, 7);
			Text(pTmpBuffer, pTmpColor, L"RESTART", 5 * 16 + 2, nScreenWidth / 2 + 2, 10);
			Text(pTmpBuffer, pTmpColor, L"SAVE", 5 * 16 + 2, nScreenWidth / 2 - 6, 14);
			Text(pTmpBuffer, pTmpColor, L"SETTING", 5 * 16 + 2, nScreenWidth / 2 + 2, 17);
			Text(pTmpBuffer, pTmpColor, L"HELP", 5 * 16 + 6, nScreenWidth / 2 - 6, 21);
			Text(pTmpBuffer, pTmpColor, L"QUIT", 5 * 16 + 2, nScreenWidth / 2 + 3, 24);
			break;
		}
		case 6:
		{
			Text(pTmpBuffer, pTmpColor, L"RESUME", 5 * 16 + 2, nScreenWidth / 2 - 7, 7);
			Text(pTmpBuffer, pTmpColor, L"RESTART", 5 * 16 + 2, nScreenWidth / 2 + 2, 10);
			Text(pTmpBuffer, pTmpColor, L"SAVE", 5 * 16 + 2, nScreenWidth / 2 - 6, 14);
			Text(pTmpBuffer, pTmpColor, L"SETTING", 5 * 16 + 2, nScreenWidth / 2 + 2, 17);
			Text(pTmpBuffer, pTmpColor, L"HELP", 5 * 16 + 2, nScreenWidth / 2 - 6, 21);
			Text(pTmpBuffer, pTmpColor, L"QUIT", 5 * 16 + 6, nScreenWidth / 2 + 3, 24);
			break;
		}
		}
		Display(pTmpBuffer, pTmpColor, 0, 0, nScreenWidth - 1, nScreenHeight - 1);
	}
	delete[] pTmpColor;
	delete[] pTmpBuffer;
	return 0;
}

static _POINT cheo1(_POINT move, int i, bool isIncrease)
{
	_POINT point{};
	if (isIncrease)
		point = { move._X + i, move._Y + i, move.flag };
	else
		point = { move._X - i, move._Y - i, move.flag };
	return point;
}
static _POINT cheo2(_POINT move, int i, bool isIncrease)
{
	_POINT point{};
	if (isIncrease)
		point = { move._X + i, move._Y - i, move.flag };
	else
		point = { move._X - i, move._Y + i, move.flag };
	return point;
}
static _POINT ngang(_POINT move, int i, bool isIncrease)
{
	_POINT point{};
	if (isIncrease)
		point = { move._X + i, move._Y, move.flag };
	else
		point = { move._X - i, move._Y, move.flag };
	return point;
}
static _POINT doc(_POINT move, int i, bool isIncrease)
{
	_POINT point{};
	if (isIncrease)
		point = { move._X, move._Y + i, move.flag };
	else
		point = { move._X, move._Y - i, move.flag };
	return point;
}
static int count(_POINT move, _POINT(*direction) (_POINT, int, bool))
{
	int count = 0;
	for (int mode = 0; mode < 2; mode++)
	{
		for (int i = 1; i < 5; i++)
		{
			_POINT point = direction(move, i, mode);
			if (!checkInBoard(point))
				break;

			if (CARO_BOARD[point._X][point._Y] == move.flag)
				count++;
			else
				break;
		}
	}
	return count + 1;
}
static bool checkInBoard(_POINT move)
{
	if (move._X < 0 || move._X >= BOARD_SIZE || move._Y < 0 || move._Y >= BOARD_SIZE)
		return false;
	return true;
}
static bool checkFullBoard()
{
	for (int i = 0; i < BOARD_SIZE; i++)
		for (int j = 0; j < BOARD_SIZE; j++)
			if (CARO_BOARD[i][j] == 0)
				return false;
	return true;
}

static bool checkRange(_POINT move)
{
	for (int i = -2; i <= 2; i++)
	{
		if (move._X + i < 0 || move._X + i >= BOARD_SIZE)
			continue;
		for (int j = -2; j <= 2; j++)
		{
			if (move._Y + j < 0 || move._Y + j >= BOARD_SIZE)
				continue;

			if (CARO_BOARD[move._X + i][move._Y + j] != 0)
				return true;
		}
	}
	return false;
}

int checkResultBoard()
{
	if (count(Move, cheo1) >= 5 || count(Move, cheo2) >= 5 || count(Move, ngang) >= 5 || count(Move, doc) >= 5)
		return Move.flag;
	if (checkFullBoard())
		return 0;
	return 2;
}

static long calAtk(_POINT move, _POINT(*direction) (_POINT, int, bool), int level)
{
	int quanTaGan = 0, quanDich = 0;
	int empty_phai = 0, empty_trai = 0, quanTaXa_phai = 0, quanTaXa_trai = 0;
	for (int i = 1; i < 5; i++)
	{
		_POINT point = direction(move, i, true);

		if (CARO_BOARD[point._X][point._Y] == -1 * move.flag || !checkInBoard(point))
		{
			if (empty_phai == 0)
				quanDich++;
			break;
		}

		if (CARO_BOARD[point._X][point._Y] == move.flag && empty_phai == 0)
			quanTaGan++;

		if (CARO_BOARD[point._X][point._Y] == move.flag && empty_phai == 1)
			quanTaXa_phai++;

		if (CARO_BOARD[point._X][point._Y] == 0)
		{
			empty_phai++;
			if (empty_phai > 1)
				break;
		}
	}
	for (int i = 1; i < 5; i++)
	{
		_POINT point = direction(move, i, false);

		if (CARO_BOARD[point._X][point._Y] == -1 * move.flag || !checkInBoard(point))
		{
			if (empty_trai == 0)
				quanDich++;
			break;
		}

		if (CARO_BOARD[point._X][point._Y] == move.flag && empty_trai == 0)
			quanTaGan++;

		if (CARO_BOARD[point._X][point._Y] == move.flag && empty_trai == 1)
			quanTaXa_trai++;

		if (CARO_BOARD[point._X][point._Y] == 0)
		{
			empty_trai++;
			if (empty_trai > 1)
				break;
		}
	}
	if (quanTaGan >= 4)
		return ATK[level][4];
	if (quanDich == 2)
		return ATK[level][0];

	if (quanTaGan == 3 && quanDich == 0 ||
		quanTaGan == 2 && quanTaXa_phai >= 1 && quanTaXa_trai >= 1 ||
		quanTaGan == 1 && quanTaXa_phai >= 2 && quanTaXa_trai >= 2)
		return ATK[level][3];

	if (quanTaGan == 2 && quanDich == 0 ||
		quanTaGan == 3 && quanDich == 1 ||
		quanDich == 0 && quanTaXa_phai >= 2 && empty_phai >= 2 ||
		quanDich == 0 && quanTaXa_trai >= 2 && empty_trai >= 2 ||
		quanTaGan == 1 && quanTaXa_phai >= 2 && empty_phai == 1 ||
		quanTaGan == 1 && quanTaXa_trai >= 2 && empty_trai == 1)
		return ATK[level][2];

	if (quanTaGan == 1 && quanDich == 0 ||
		quanTaGan == 2 && quanDich == 1)
		return ATK[level][1];
	return ATK[level][0];
}
static long calDef(_POINT move, _POINT(*direction) (_POINT, int, bool), int level)
{
	int quanTa = 0, quanDichGan = 0;
	int empty_phai = 0, empty_trai = 0, quanDichXa_phai = 0, quanDichXa_trai = 0;
	for (int i = 1; i < 5; i++)
	{
		_POINT point = direction(move, i, true);

		if (CARO_BOARD[point._X][point._Y] == move.flag || !checkInBoard(point))
		{
			if (empty_phai == 0)
				quanTa++;
			break;
		}

		if (CARO_BOARD[point._X][point._Y] == -1 * move.flag && empty_phai == 0)
			quanDichGan++;

		if (CARO_BOARD[point._X][point._Y] == -1 * move.flag && empty_phai == 1)
			quanDichXa_phai++;

		if (CARO_BOARD[point._X][point._Y] == 0)
		{
			empty_phai++;
			if (empty_phai > 1)
				break;
		}
	}
	for (int i = 1; i < 5; i++)
	{
		_POINT point = direction(move, i, false);

		if (CARO_BOARD[point._X][point._Y] == move.flag || !checkInBoard(point))
		{
			if (empty_trai == 0)
				quanTa++;
			break;
		}

		if (CARO_BOARD[point._X][point._Y] == -1 * move.flag && empty_trai == 0)
			quanDichGan++;

		if (CARO_BOARD[point._X][point._Y] == -1 * move.flag && empty_trai == 1)
			quanDichXa_trai++;

		if (CARO_BOARD[point._X][point._Y] == 0)
		{
			empty_trai++;
			if (empty_trai > 1)
				break;
		}
	}
	if (quanDichGan >= 4)
		return DEF[level][4];
	if (quanTa == 2)
		return DEF[level][0];

	if (quanDichGan == 3 && quanTa == 0 ||
		quanDichGan == 2 && quanDichXa_phai >= 1 && quanDichXa_trai >= 1 ||
		quanDichGan == 1 && quanDichXa_phai >= 2 && quanDichXa_trai >= 2)
		return DEF[level][3];

	if (quanDichGan == 2 && quanTa == 0 ||
		quanDichGan == 3 && quanTa == 1 ||
		quanTa == 0 && quanDichXa_phai >= 2 && empty_phai >= 2 ||
		quanTa == 0 && quanDichXa_trai >= 2 && empty_trai >= 2 ||
		quanDichGan == 1 && quanDichXa_phai >= 2 && empty_phai == 1 ||
		quanDichGan == 1 && quanDichXa_trai >= 2 && empty_trai == 1)
		return DEF[level][2];

	if (quanDichGan == 1 && quanTa == 0 ||
		quanDichGan == 2 && quanTa == 1)
		return DEF[level][1];
	return DEF[level][0];
}
_POINT goFirst(int level)
{
	//quân -1 đi trước nên nếu flag = 1 thì máy đi trước với quân -1
	//nếu người đi sát cạnh bàn cờ thì máy đi giữa bàn cờ mà không cần chặn
	if (Move.flag == 1 || Move._X < 2 || Move._X > BOARD_SIZE - 3 || Move._Y < 2 || Move._Y > BOARD_SIZE - 3)
		return { BOARD_SIZE / 2 - 1, BOARD_SIZE / 2 - 1, (-1) * Move.flag };
	return findBest((-1) * Move.flag, level);
}
_POINT findBest(int flag, int level)
{
	long bestVal = 0;
	vector<_POINT> arrMove{};
	for (int i = 0; i < BOARD_SIZE; i++)
	{
		for (int j = 0; j < BOARD_SIZE; j++)
		{
			_POINT move = { i, j, flag };
			if (CARO_BOARD[i][j] == 0)
			{
				if (!checkRange(move))
					continue;
				long totalAtk = calAtk(move, cheo1, level) + calAtk(move, cheo2, level) + calAtk(move, ngang, level) + calAtk(move, doc, level);
				long totalDef = calDef(move, cheo1, level) + calDef(move, cheo2, level) + calDef(move, ngang, level) + calDef(move, doc, level);
				long tmp = (totalAtk > totalDef) ? totalAtk : totalDef;

				if (tmp > bestVal)
				{
					bestVal = tmp;
					arrMove = {};
				}
				if (tmp == bestVal)
					arrMove.push_back(move);
			}
		}
	}
	int idBest = rand() % arrMove.size();
	return arrMove[idBest];
}

wstring int_to_wstr(int num)
{
	if (num == 0)
		return L"0";

	wstring wstr{};
	for (; num != 0; num /= 10)
	{
		wstr.push_back(char(num % 10 + 48));
	}
	reverse(wstr.begin(), wstr.end());
	return wstr;
}
//Back: 1, Quit: 2
int PlaywHum(bool switch_file)
{
	if (!switch_file)
	{
		while (1)
		{
			Player1.Name = L"[Player 1]";
			Player2.Name = L"[Player 2]";
			if (enterName(pBuffer, pColor, Player1.Name, L"PLAYER_1'S NAME", 44, 12))
			{
				if (enterName(pBuffer, pColor, Player2.Name, L"PLAYER_2'S NAME", 44, 12))
					break;
			}
			else
			{
				ClearScreen(1, 0);
				Background();
				return 1;
			}
		}
	}

	ClearScreen(1, 0);
	Board(12, 12, 35, 1);

	int result = 2;
	bool isPlayAgain = false;
	bool isRestart = false;

	int xWease = 13, xFox = 97, colorWease = 14, colorFox = 10;
	wstring wstrWins{}, wstrTime_min{}, wstrTime_sec{}, wstrMoves{};

	//Khởi tạo bàn cờ
	if (switch_file != 1)
	{
		Player1.Wins = 0;
		Player2.Wins = 0;
		Round = 1;

		for (int i = 0; i < BOARD_SIZE; i++)
		{
			for (int j = 0; j < BOARD_SIZE; j++)
				CARO_BOARD[i][j] = 0;
		}
		Move = { BOARD_SIZE / 2 - 1, BOARD_SIZE / 2 - 1, 1 };
		currentX = 37 + (BOARD_SIZE / 2 - 1) * 4;
		currentY = 2 + (BOARD_SIZE / 2 - 1) * 2;
		Player1.Time = 900;
		Player1.Moves = 0;
		Player2.Time = 900;
		Player2.Moves = 0;
	}
	while (1)
	{
		Player& playerX = (Round % 2 == 1) ? Player1 : Player2, & playerO = (Round % 2 != 1) ? Player1 : Player2;

		BackgroundOngame();
		int xX = (Round % 2 == 1) ? xWease : xFox, xO = (Round % 2 != 1) ? xWease : xFox,
			colorX = (Round % 2 == 1) ? colorWease : colorFox, colorO = (Round % 2 != 1) ? colorWease : colorFox;
		for (int j = 12; j < 12 + 6; j++)
		{
			for (int i = 13; i < 13 + 9; i++)
				pBuffer[j * nScreenWidth + i] = L' ';
			for (int i = 97; i < 97 + 9; i++)
				pBuffer[j * nScreenWidth + i] = L' ';
		}
		DrawObject(X, 1 * 16 + colorX, xX, 12);
		DrawObject(O, 1 * 16 + colorO, xO, 12);

		Text(Player1.Name, 5 * 16 + 2, 16 - Player1.Name.length() / 2, 4);

		Text(L"WINS: ", 5 * 16 + 2, 8, 6);
		wstrWins = int_to_wstr(Player1.Wins);
		Text(wstrWins, 5 * 16 + 2, 14, 6);

		Text(L"TIME LEFT: ", 5 * 16 + 2, 8, 8);
		wstrTime_min = int_to_wstr(Player1.Time / 60);
		if (Player1.Time / 60 < 10)
			wstrTime_min = L"0" + wstrTime_min;
		wstrTime_sec = int_to_wstr(Player1.Time % 60);
		if (Player1.Time % 60 < 10)
			wstrTime_sec = L"0" + wstrTime_sec;
		Text(wstrTime_min + L":" + wstrTime_sec, 5 * 16 + 2, 19, 8);

		Text(L"MOVES: ", 5 * 16 + 2, 8, 10);
		wstrMoves = int_to_wstr(Player1.Moves);
		Text(wstrMoves, 5 * 16 + 2, 15, 10);

		Text(Player2.Name, 5 * 16 + 2, 100 - Player2.Name.length() / 2, 4);

		Text(L"WINS: ", 5 * 16 + 2, 92, 6);
		wstrWins = int_to_wstr(Player2.Wins);
		Text(wstrWins, 5 * 16 + 2, 98, 6);

		Text(L"TIME LEFT: ", 5 * 16 + 2, 92, 8);
		wstrTime_min = int_to_wstr(Player2.Time / 60);
		if (Player2.Time / 60 < 10)
			wstrTime_min = L"0" + wstrTime_min;
		wstrTime_sec = int_to_wstr(Player2.Time % 60);
		if (Player2.Time % 60 < 10)
			wstrTime_sec = L"0" + wstrTime_sec;
		Text(wstrTime_min + L":" + wstrTime_sec, 5 * 16 + 2, 103, 8);

		Text(L"MOVES: ", 5 * 16 + 2, 92, 10);
		wstrMoves = int_to_wstr(Player2.Moves);
		Text(wstrMoves, 5 * 16 + 2, 99, 10);

		Text(L"ROUND ", 5 * 16 + 2, 25, 22);
		Text(int_to_wstr(Round), 5 * 16 + 2, 31, 22);
		Display();
		printMatrix();

		gotoXY(currentX, currentY);
		_POINT newMove = {};
		int stick = 0;

		Player* pPlayer = NULL;
		int tmp{};
		bool isUndo = false;

		while (1)
		{
			newMove = { Move._X, Move._Y, (-1) * Move.flag };
			pPlayer = (newMove.flag == -1) ? &playerX : &playerO;

			stick = 0;
			bool bKey[7]{};

			gotoXY(currentX, currentY);
			ShowCur(1);

			while (1)
			{
				//Game Timing
				stick++;
				if (stick >= 12)
				{
					pPlayer->Time--;
					if (pPlayer->Time <= 0)
					{
						tmp = (newMove.flag == -1) ? ((Round % 2 == 1) ? 19 : 103) : ((Round % 2 != 1) ? 19 : 103);
						Text(L"00:00", 5 * 16 + 2, tmp, 8);
						break;
					}
					stick = 1;
				}
				wstrTime_min = int_to_wstr(pPlayer->Time / 60);
				if (pPlayer->Time / 60 < 10)
					wstrTime_min = L"0" + wstrTime_min;
				wstrTime_sec = int_to_wstr(pPlayer->Time % 60);
				if (pPlayer->Time % 60 < 10)
					wstrTime_sec = L"0" + wstrTime_sec;
				tmp = (newMove.flag == -1) ? ((Round % 2 == 1) ? 19 : 103) : ((Round % 2 != 1) ? 19 : 103);
				Text(wstrTime_min + L":" + wstrTime_sec, 5 * 16 + 2, tmp, 8);
				Display();

				for (int i = 0; i < 7; i++)
				{
					tmp = (newMove.flag == -1) ? ((Round % 2 == 1) ? i : i + 7) : ((Round % 2 != 1) ? i : i + 7);
					if (bKey[i] = GetAsyncKeyState(key[tmp]) < 0)
					{
						while (bKey[i])
						{
							bKey[i] = GetAsyncKeyState(key[tmp]) < 0;
						}
						bKey[i] = true;
					}
				}

				//W or up arrow
				if (bKey[0])
				{
					if (sound)
						playSound(4);

					if (currentY - 2 >= 2)
					{
						currentY -= 2;
						newMove._Y -= 1;
						gotoXY(currentX, currentY);
					}
					else
					{
						currentY = 26 - 2;
						newMove._Y = BOARD_SIZE - 1;
						gotoXY(currentX, currentY);
					}
				}
				//A or left arrow
				if (bKey[1])
				{
					if (sound)
						playSound(4);

					if (currentX - 4 >= 37)
					{
						currentX -= 4;
						newMove._X -= 1;
						gotoXY(currentX, currentY);
					}
					else
					{
						currentX = 85 - 4;
						newMove._X = BOARD_SIZE - 1;
						gotoXY(currentX, currentY);
					}
				}
				//S or down arrow
				if (bKey[2])
				{
					if (sound)
						playSound(4);

					if (currentY + 2 < 26)
					{
						currentY += 2;
						newMove._Y += 1;
						gotoXY(currentX, currentY);
					}
					else
					{
						currentY = 2;
						newMove._Y = 0;
						gotoXY(currentX, currentY);
					}
				}
				//D or right arrow
				if (bKey[3])
				{
					if (sound)
						playSound(4);

					if (currentX + 4 < 85)
					{
						currentX += 4;
						newMove._X += 1;
						gotoXY(currentX, currentY);
					}
					else
					{
						currentX = 37;
						newMove._X = 0;
						gotoXY(currentX, currentY);
					}
				}

				//space or enter
				if (bKey[4])
				{
					if (sound)
						playSound(1);

					if (CARO_BOARD[newMove._X][newMove._Y] == 0)
					{
						Move = newMove;
						CARO_BOARD[newMove._X][newMove._Y] = newMove.flag;

						pPlayer->Moves++;
						wstrMoves = int_to_wstr(pPlayer->Moves);
						tmp = (newMove.flag == -1) ? ((Round % 2 == 1) ? 15 : 99) : ((Round % 2 != 1) ? 15 : 99);
						Text(wstrMoves, 5 * 16 + 2, tmp, 10);
						isUndo = false;
						break;
					}
				}

				//U - Undo
				if (bKey[5] && !isUndo)
				{
					if (sound)
						playSound(0);

					isUndo = true;
					CARO_BOARD[Move._X][Move._Y] = 0;
					currentX = 37 + 4 * Move._X; currentY = 2 + 2 * Move._Y;
					Move.flag = newMove.flag;

					pPlayer = (newMove.flag != -1) ? &playerX : &playerO;
					pPlayer->Moves--;

					wstrMoves = int_to_wstr(pPlayer->Moves);
					tmp = (newMove.flag != -1) ? ((Round % 2 == 1) ? 15 : 99) : ((Round % 2 != 1) ? 15 : 99);
					Text(wstrMoves, 5 * 16 + 2, tmp, 10);
					break;
				}
				//Esc - Pause
				if (bKey[6])
				{
					if (sound)
						playSound(0);

					FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
					int pause = Pause(-1, switch_file);
					if (pause == -2)
					{
						isRestart = true;
						break;
					}
					if (pause == -3 || pause == -6)
						return pause;
					ShowCur(1);
				}

				Sleep(5);
			}
			if (isRestart)
			{
				isRestart = false;
				break;
			}
			printMatrix();

			//check result
			result = checkResultBoard();
			if (pPlayer->Time <= 0)
				result = newMove.flag * -1;
			if (result != 2)
			{
				FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
				ShowCur(0);

				WORD* pTmpColor = new WORD[nScreenWidth * nScreenHeight];
				wchar_t* pTmpBuffer = new wchar_t[nScreenWidth * nScreenHeight];

				for (int j = 9; j <= 17; j++)
					for (int i = 38; i <= 80; i++)
					{
						pTmpColor[j * nScreenWidth + i] = pColor[j * nScreenWidth + i];
						pTmpBuffer[j * nScreenWidth + i] = pBuffer[j * nScreenWidth + i];
					}
				if (music)
					PlaySound(nullptr, nullptr, 0);
				switch (result)
				{
				case -1:
					Blinking(pTmpBuffer, pTmpColor, XWins, 7, 8, 3, 38, 10);
					DrawObject(pTmpBuffer, pTmpColor, XWins, 1 * 16 + 3, 38, 10);
					Text(pTmpBuffer, pTmpColor, L"Press any key to continue!", 1 * 16 + 3, 46, 17);
					playerX.Wins++;
					break;
				case 1:
					Blinking(pTmpBuffer, pTmpColor, OWins, 7, 8, 6, 38, 10);
					DrawObject(pTmpBuffer, pTmpColor, OWins, 1 * 16 + 6, 38, 10);
					Text(pTmpBuffer, pTmpColor, L"Press any key to continue!", 1 * 16 + 6, 46, 17);
					playerO.Wins++;
					break;
				case 0:
					Blinking(pTmpBuffer, pTmpColor, Draw, 7, 8, 8, 43, 10);
					DrawObject(pTmpBuffer, pTmpColor, Draw, 1 * 16 + 8, 43, 10);
					Text(pTmpBuffer, pTmpColor, L"Press any key to continue!", 1 * 16 + 8, 46, 17);
					break;
				}
				if (music)
					PlaySound(L"main_music.wav", NULL, SND_FILENAME | SND_LOOP | SND_ASYNC);
				Display(pTmpBuffer, pTmpColor, 38, 9, 80, 17);
				_getch();
				if (sound)
					playSound(0);

				//Play Again
				drawNotiBoard(pTmpBuffer, pTmpColor, 44, 9, 30, 15);
				Text(pTmpBuffer, pTmpColor, L"PLAY AGAIN ?", 16 * 5 + 2, 53, 11);
				Text(pTmpBuffer, pTmpColor, L"YES", 16 * 5 + 6, 50, 14);
				Text(pTmpBuffer, pTmpColor, L"NO", 16 * 5 + 2, 65, 14);
				Text(pTmpBuffer, pTmpColor, L"|", 5 * 16 + 4, 59, 14);

				Display(pTmpBuffer, pTmpColor, 38, 9, 80, 17);

				int select = 1;
				while (1)
				{
					int move = toupper(_getch());

					if (move == 'D' || move == 77 || move == 'A' || move == 75)
					{
						if (sound)
							playSound(4);

						select = (select != 1) ? 1 : 2;
					}
					if (move == 13 || move == 32)
					{
						if (sound)
							playSound(0);

						if (select == 1)
						{
							Round++;
							isPlayAgain = 1;
							break;
						}
						else
						{
							delete[] pTmpBuffer;
							delete[] pTmpColor;
							return 2;
						}
					}
					switch (select)
					{
					case 1:
						Text(pTmpBuffer, pTmpColor, L"YES", 16 * 5 + 6, 50, 14);
						Text(pTmpBuffer, pTmpColor, L"NO", 16 * 5 + 2, 65, 14);
						break;
					case 2:
						Text(pTmpBuffer, pTmpColor, L"YES", 16 * 5 + 2, 50, 14);
						Text(pTmpBuffer, pTmpColor, L"NO", 16 * 5 + 6, 65, 14);
						break;
					}
					// Hiển thị
					Display(pTmpBuffer, pTmpColor, 38, 9, 80, 17);
				}
				delete[] pTmpBuffer;
				delete[] pTmpColor;
			}
			if (isPlayAgain)
				break;
		}
		for (int i = 0; i < BOARD_SIZE; i++)
		{
			for (int j = 0; j < BOARD_SIZE; j++)
				CARO_BOARD[i][j] = 0;
		}
		Move = { BOARD_SIZE / 2 - 1, BOARD_SIZE / 2 - 1, 1 };
		currentX = 37 + (BOARD_SIZE / 2 - 1) * 4;
		currentY = 2 + (BOARD_SIZE / 2 - 1) * 2;
		Player1.Time = 900;
		Player1.Moves = 0;
		Player2.Time = 900;
		Player2.Moves = 0;
		isPlayAgain = false;
	}
}
int PlaywCom(bool switch_file, int level)
{
	if (!switch_file)
	{
		Player1.Name = L"[Player]";
		if (enterName(pBuffer, pColor, Player1.Name, L"PLAYER", 44, 12) == 0)
		{
			ClearScreen(1, 0);
			Background();
			return 1;
		}

		Player2.Name = L"BOT";

		ClearScreen(1, 0);
		Background();
		DrawObject(GameMode, 2 * 16 + 3, nScreenWidth / 2 - GameMode[0].length() / 2, 3);

		drawNotiBoard2(nScreenWidth / 2 - 8, 11, 16, 6);
		Text(L"EASY", 5 * 16 + 6, nScreenWidth / 2 - 2, 12);
		drawNotiBoard2(nScreenWidth / 2 - 8, 15, 16, 6);
		Text(L"MEDIUM", 5 * 16 + 2, nScreenWidth / 2 - 3, 16);
		drawNotiBoard2(nScreenWidth / 2 - 8, 19, 16, 6);
		Text(L"HARD", 5 * 16 + 2, nScreenWidth / 2 - 2, 20);
		drawNotiBoard2(nScreenWidth / 2 - 8, 23, 16, 6);
		Text(L"BACK", 5 * 16 + 2, nScreenWidth / 2 - 2, 24);
		Display();

		//select level
		int nSelect = 1;

		while (1)
		{
			int move = toupper(_getch());

			if (move == 'S' || move == 80)
			{
				if (sound)
					playSound(4);

				nSelect++;
				if (nSelect > 4)
					nSelect -= 4;
			}
			if (move == 'W' || move == 72)
			{
				if (sound)
					playSound(4);

				nSelect--;
				if (nSelect < 1)
					nSelect += 4;
			}
			if (move == 13 || move == 32)
			{
				if (sound)
					playSound(0);

				if (nSelect == 4)
				{
					ClearScreen(1, 0);
					Background();
					return 1;
				}
				level = nSelect - 1;
				break;
			}
			DrawObject(GameMode, 2 * 16 + 3, nScreenWidth / 2 - GameMode[0].length() / 2, 3);

			switch (nSelect)
			{
			case 1:
			{
				drawNotiBoard2(nScreenWidth / 2 - 8, 11, 16, 6);
				Text(L"EASY", 5 * 16 + 6, nScreenWidth / 2 - 2, 12);
				drawNotiBoard2(nScreenWidth / 2 - 8, 15, 16, 6);
				Text(L"MEDIUM", 5 * 16 + 2, nScreenWidth / 2 - 3, 16);
				drawNotiBoard2(nScreenWidth / 2 - 8, 19, 16, 6);
				Text(L"HARD", 5 * 16 + 2, nScreenWidth / 2 - 2, 20);
				drawNotiBoard2(nScreenWidth / 2 - 8, 23, 16, 6);
				Text(L"BACK", 5 * 16 + 2, nScreenWidth / 2 - 2, 24);
				break;
			}
			case 2:
			{
				drawNotiBoard2(nScreenWidth / 2 - 8, 11, 16, 6);
				Text(L"EASY", 5 * 16 + 2, nScreenWidth / 2 - 2, 12);
				drawNotiBoard2(nScreenWidth / 2 - 8, 15, 16, 6);
				Text(L"MEDIUM", 5 * 16 + 6, nScreenWidth / 2 - 3, 16);
				drawNotiBoard2(nScreenWidth / 2 - 8, 19, 16, 6);
				Text(L"HARD", 5 * 16 + 2, nScreenWidth / 2 - 2, 20);
				drawNotiBoard2(nScreenWidth / 2 - 8, 23, 16, 6);
				Text(L"BACK", 5 * 16 + 2, nScreenWidth / 2 - 2, 24);
				break;
			}
			case 3:
			{
				drawNotiBoard2(nScreenWidth / 2 - 8, 11, 16, 6);
				Text(L"EASY", 5 * 16 + 2, nScreenWidth / 2 - 2, 12);
				drawNotiBoard2(nScreenWidth / 2 - 8, 15, 16, 6);
				Text(L"MEDIUM", 5 * 16 + 2, nScreenWidth / 2 - 3, 16);
				drawNotiBoard2(nScreenWidth / 2 - 8, 19, 16, 6);
				Text(L"HARD", 5 * 16 + 6, nScreenWidth / 2 - 2, 20);
				drawNotiBoard2(nScreenWidth / 2 - 8, 23, 16, 6);
				Text(L"BACK", 5 * 16 + 2, nScreenWidth / 2 - 2, 24);
				break;
			}
			case 4:
			{
				drawNotiBoard2(nScreenWidth / 2 - 8, 11, 16, 6);
				Text(L"EASY", 5 * 16 + 2, nScreenWidth / 2 - 2, 12);
				drawNotiBoard2(nScreenWidth / 2 - 8, 15, 16, 6);
				Text(L"MEDIUM", 5 * 16 + 2, nScreenWidth / 2 - 3, 16);
				drawNotiBoard2(nScreenWidth / 2 - 8, 19, 16, 6);
				Text(L"HARD", 5 * 16 + 2, nScreenWidth / 2 - 2, 20);
				drawNotiBoard2(nScreenWidth / 2 - 8, 23, 16, 6);
				Text(L"BACK", 5 * 16 + 6, nScreenWidth / 2 - 2, 24);
			}
			}
			// Hiển thị
			Display();
		}
	}

	ClearScreen(1, 0);
	Board(12, 12, 35, 1);

	int result = 2;
	bool isPlayAgain = false;
	bool isRestart = false;

	wstring wstrWins{}, wstrMoves{};

	//Khởi tạo bàn cờ
	if (switch_file != 1)
	{
		Player1.Wins = 0;
		Player2.Wins = 0;
		Round = 1;

		for (int i = 0; i < BOARD_SIZE; i++)
		{
			for (int j = 0; j < BOARD_SIZE; j++)
				CARO_BOARD[i][j] = 0;
		}
		Move = { BOARD_SIZE / 2 - 1, BOARD_SIZE / 2 - 1, 1 };
		currentX = 37 + (BOARD_SIZE / 2 - 1) * 4;
		currentY = 2 + (BOARD_SIZE / 2 - 1) * 2;
		Player1.Time = 900;
		Player1.Moves = 0;
		Player2.Time = 900;
		Player2.Moves = 0;
	}
	while (1)
	{
		BackgroundOngame();
		DrawObject(X, 1 * 16 + 14, 13, 12);
		DrawObject(O, 1 * 16 + 10, 97, 12);

		Text(Player1.Name, 5 * 16 + 2, 16 - Player1.Name.length() / 2, 4);

		Text(L"WINS: ", 5 * 16 + 2, 8, 6);
		wstrWins = int_to_wstr(Player1.Wins);
		Text(wstrWins, 5 * 16 + 2, 14, 6);

		Text(L"TIME LEFT: ", 5 * 16 + 2, 8, 8);
		Text(L"15:00", 5 * 16 + 2, 19, 8);

		Text(L"MOVES: ", 5 * 16 + 2, 8, 10);
		wstrMoves = int_to_wstr(Player1.Moves);
		Text(wstrMoves, 5 * 16 + 2, 15, 10);

		Text(Player2.Name, 5 * 16 + 2, 100 - Player2.Name.length() / 2, 4);

		Text(L"WINS: ", 5 * 16 + 2, 92, 6);
		wstrWins = int_to_wstr(Player2.Wins);
		Text(wstrWins, 5 * 16 + 2, 98, 6);

		Text(L"TIME LEFT: ", 5 * 16 + 2, 92, 8);
		Text(L"15:00", 5 * 16 + 2, 103, 8);

		Text(L"MOVES: ", 5 * 16 + 2, 92, 10);
		wstrMoves = int_to_wstr(Player2.Moves);
		Text(wstrMoves, 5 * 16 + 2, 99, 10);

		Text(L"ROUND ", 5 * 16 + 2, 25, 22);
		Text(int_to_wstr(Round), 5 * 16 + 2, 31, 22);

		Display();
		printMatrix();
		gotoXY(currentX, currentY);

		bool isUndo = false;
		_POINT newMove = { Move._X, Move._Y, -1 * Move.flag };

		//Hum gofirst
		ShowCur(1);
		while (1)
		{
			int move = toupper(_getch());

			if (move == 'S' || move == 80)
			{
				if (sound)
					playSound(4);

				if (currentY + 2 < 26)
				{
					currentY += 2;
					gotoXY(currentX, currentY);
					newMove._Y += 1;
				}
				else
				{
					currentY = 2;
					gotoXY(currentX, currentY);
					newMove._Y = 0;
				}
			}
			if (move == 'W' || move == 72)
			{
				if (sound)
					playSound(4);

				if (currentY - 2 >= 2)
				{
					currentY -= 2;
					gotoXY(currentX, currentY);
					newMove._Y -= 1;
				}
				else
				{
					currentY = 26 - 2;
					gotoXY(currentX, currentY);
					newMove._Y = BOARD_SIZE - 1;
				}
			}
			if (move == 'A' || move == 75)
			{
				if (sound)
					playSound(4);

				if (currentX - 4 >= 37)
				{
					currentX -= 4;
					gotoXY(currentX, currentY);
					newMove._X -= 1;
				}
				else
				{
					currentX = 85 - 4;
					gotoXY(currentX, currentY);
					newMove._X = BOARD_SIZE - 1;
				}
			}
			if (move == 'D' || move == 77)
			{
				if (sound)
					playSound(4);

				if (currentX + 4 < 85)
				{
					currentX += 4;
					gotoXY(currentX, currentY);
					newMove._X += 1;
				}
				else
				{
					currentX = 37;
					gotoXY(currentX, currentY);
					newMove._X = 0;
				}
			}
			if (move == 13 || move == 32)
			{
				if (sound)
					playSound(1);

				if (CARO_BOARD[newMove._X][newMove._Y] == 0)
				{
					CARO_BOARD[newMove._X][newMove._Y] = newMove.flag;
					Move = newMove;
					Player1.Moves++;
					wstrMoves = int_to_wstr(Player1.Moves);
					Text(wstrMoves, 5 * 16 + 2, 15, 10);
					break;
				}
			}
			if (move == 27)
			{
				if (sound)
					playSound(0);

				FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
				int pause = Pause(level, switch_file);
				if (pause == -2)
				{
					isRestart = true;
					break;
				}
				if (pause == -3 || pause == -6)
					return pause;
				ShowCur(1);
			}
		}
		if (isRestart)
		{
			isRestart = false;
			continue;
		}
		_POINT undoMove = Move;

		//Com gofirst
		Move = goFirst(level);
		currentX += 4 * (Move._X - newMove._X);
		currentY += 2 * (Move._Y - newMove._Y);
		CARO_BOARD[Move._X][Move._Y] = Move.flag;

		Player2.Moves++;
		wstrMoves = int_to_wstr(Player2.Moves);
		Text(wstrMoves, 5 * 16 + 2, 99, 10);

		printMatrix();

		while (1)
		{
			newMove = { Move._X, Move._Y, (-1) * Move.flag };

			printMatrix();
			gotoXY(currentX, currentY);
			ShowCur(1);

			while (1)
			{
				Display();
				int move = toupper(_getch());

				if (move == 'S' || move == 80)
				{
					if (sound)
						playSound(4);

					if (currentY + 2 < 26)
					{
						currentY += 2;
						gotoXY(currentX, currentY);
						newMove._Y += 1;
					}
					else
					{
						currentY = 2;
						gotoXY(currentX, currentY);
						newMove._Y = 0;
					}
				}
				if (move == 'W' || move == 72)
				{
					if (sound)
						playSound(4);

					if (currentY - 2 >= 2)
					{
						currentY -= 2;
						gotoXY(currentX, currentY);
						newMove._Y -= 1;
					}
					else
					{
						currentY = 26 - 2;
						gotoXY(currentX, currentY);
						newMove._Y = BOARD_SIZE - 1;
					}
				}
				if (move == 'A' || move == 75)
				{
					if (sound)
						playSound(4);

					if (currentX - 4 >= 37)
					{
						currentX -= 4;
						gotoXY(currentX, currentY);
						newMove._X -= 1;
					}
					else
					{
						currentX = 85 - 4;
						gotoXY(currentX, currentY);
						newMove._X = BOARD_SIZE - 1;
					}
				}
				if (move == 'D' || move == 77)
				{
					if (sound)
						playSound(4);

					if (currentX + 4 < 85)
					{
						currentX += 4;
						gotoXY(currentX, currentY);
						newMove._X += 1;
					}
					else
					{
						currentX = 37;
						gotoXY(currentX, currentY);
						newMove._X = 0;
					}
				}
				if (move == 13 || move == 32)
				{
					if (sound)
						playSound(1);

					if (CARO_BOARD[newMove._X][newMove._Y] == 0)
					{
						CARO_BOARD[newMove._X][newMove._Y] = newMove.flag;
						Move = newMove;
						Player1.Moves++;
						wstrMoves = int_to_wstr(Player1.Moves);
						Text(wstrMoves, 5 * 16 + 2, 15, 10);
						isUndo = false;
						break;
					}
				}
				if (move == 27)
				{
					if (sound)
						playSound(0);

					FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
					int pause = Pause(level, switch_file);
					if (pause == -2)
					{
						isRestart = true;
						break;
					}
					if (pause == -3 || pause == -6)
						return pause;
					ShowCur(1);
				}

				if (move == 'U' && !isUndo)
				{
					if (sound)
						playSound(0);

					CARO_BOARD[Move._X][Move._Y] = 0;
					CARO_BOARD[undoMove._X][undoMove._Y] = 0;
					currentX = 37 + 4 * Move._X; currentY = 2 + 2 * Move._Y;

					Move.flag = 1;

					Player1.Moves--;
					Player2.Moves--;

					wstrMoves = int_to_wstr(Player1.Moves);
					Text(wstrMoves, 5 * 16 + 2, 15, 10);
					wstrMoves = int_to_wstr(Player2.Moves);
					Text(wstrMoves, 5 * 16 + 2, 99, 10);
					isUndo = true;
					break;
				}

			}
			if (isUndo)
				continue;
			if (isRestart)
			{
				isRestart = false;
				break;
			}
			undoMove = Move;
			printMatrix();

			//check result
			result = checkResultBoard();
			if (result != 2)
			{
				FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
				ShowCur(0);

				WORD* pTmpColor = new WORD[nScreenWidth * nScreenHeight];
				wchar_t* pTmpBuffer = new wchar_t[nScreenWidth * nScreenHeight];

				for (int j = 9; j <= 17; j++)
					for (int i = 38; i <= 80; i++)
					{
						pTmpColor[j * nScreenWidth + i] = pColor[j * nScreenWidth + i];
						pTmpBuffer[j * nScreenWidth + i] = pBuffer[j * nScreenWidth + i];
					}
				if (music)
					PlaySound(nullptr, nullptr, 0);
				switch (result)
				{
				case -1:
					Blinking(pTmpBuffer, pTmpColor, XWins, 7, 8, 3, 38, 10);
					DrawObject(pTmpBuffer, pTmpColor, XWins, 1 * 16 + 3, 38, 10);
					Text(pTmpBuffer, pTmpColor, L"Press any key to continue!", 1 * 16 + 3, 46, 17);
					Player1.Wins++;
					break;
				case 1:
					Blinking(pTmpBuffer, pTmpColor, OWins, 7, 8, 6, 38, 10);
					DrawObject(pTmpBuffer, pTmpColor, OWins, 1 * 16 + 6, 38, 10);
					Text(pTmpBuffer, pTmpColor, L"Press any key to continue!", 1 * 16 + 6, 46, 17);
					Player2.Wins++;
					break;
				case 0:
					Blinking(pTmpBuffer, pTmpColor, Draw, 7, 8, 8, 43, 10);
					DrawObject(pTmpBuffer, pTmpColor, Draw, 1 * 16 + 8, 43, 10);
					Text(pTmpBuffer, pTmpColor, L"Press any key to continue!", 1 * 16 + 8, 46, 17);
					break;
				}
				if (music)
					PlaySound(L"main_music.wav", NULL, SND_FILENAME | SND_LOOP | SND_ASYNC);
				Display(pTmpBuffer, pTmpColor, 38, 9, 80, 17);
				_getch();
				if (sound)
					playSound(0);

				//Play Again
				drawNotiBoard(pTmpBuffer, pTmpColor, 44, 9, 30, 15);
				Text(pTmpBuffer, pTmpColor, L"PLAY AGAIN ?", 16 * 5 + 2, 53, 11);
				Text(pTmpBuffer, pTmpColor, L"YES", 16 * 5 + 6, 50, 14);
				Text(pTmpBuffer, pTmpColor, L"NO", 16 * 5 + 2, 65, 14);
				Text(pTmpBuffer, pTmpColor, L"|", 5 * 16 + 4, 59, 14);

				Display(pTmpBuffer, pTmpColor, 38, 9, 80, 17);

				int select = 1;
				while (1)
				{
					int move = toupper(_getch());

					if (move == 'D' || move == 77 || move == 'A' || move == 75)
					{
						if (sound)
							playSound(4);

						select = (select != 1) ? 1 : 2;
					}
					if (move == 13 || move == 32)
					{
						if (sound)
							playSound(0);

						if (select == 1)
						{
							Round++;
							isPlayAgain = 1;
							break;
						}
						else
						{
							delete[] pTmpBuffer;
							delete[] pTmpColor;
							return 2;
						}
					}
					switch (select)
					{
					case 1:
						Text(pTmpBuffer, pTmpColor, L"YES", 16 * 5 + 6, 50, 14);
						Text(pTmpBuffer, pTmpColor, L"NO", 16 * 5 + 2, 65, 14);
						break;
					case 2:
						Text(pTmpBuffer, pTmpColor, L"YES", 16 * 5 + 2, 50, 14);
						Text(pTmpBuffer, pTmpColor, L"NO", 16 * 5 + 6, 65, 14);
						break;
					}
					// Hiển thị
					Display(pTmpBuffer, pTmpColor, 38, 9, 80, 17);
				}
				delete[] pTmpBuffer;
				delete[] pTmpColor;
			}
			if (isPlayAgain)
				break;

			Move = findBest((-1) * Move.flag, level);
			currentX += 4 * (Move._X - newMove._X);
			currentY += 2 * (Move._Y - newMove._Y);
			CARO_BOARD[Move._X][Move._Y] = Move.flag;
			//undoComMove = Move;

			Player2.Moves++;
			wstrMoves = int_to_wstr(Player2.Moves);
			Text(wstrMoves, 5 * 16 + 2, 99, 10);

			//check result
			result = checkResultBoard();
			if (result != 2)
			{
				FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
				ShowCur(0);

				WORD* pTmpColor = new WORD[nScreenWidth * nScreenHeight];
				wchar_t* pTmpBuffer = new wchar_t[nScreenWidth * nScreenHeight];

				for (int j = 9; j <= 17; j++)
					for (int i = 38; i <= 80; i++)
					{
						pTmpColor[j * nScreenWidth + i] = pColor[j * nScreenWidth + i];
						pTmpBuffer[j * nScreenWidth + i] = pBuffer[j * nScreenWidth + i];
					}
				if (music)
					PlaySound(nullptr, nullptr, 0);
				switch (result)
				{
				case -1:
					Blinking(pTmpBuffer, pTmpColor, XWins, 7, 8, 3, 38, 10);
					DrawObject(pTmpBuffer, pTmpColor, XWins, 1 * 16 + 3, 38, 10);
					Text(pTmpBuffer, pTmpColor, L"Press any key to continue!", 1 * 16 + 3, 46, 17);
					Player1.Wins++;
					break;
				case 1:
					Blinking(pTmpBuffer, pTmpColor, OWins, 7, 8, 6, 38, 10);
					DrawObject(pTmpBuffer, pTmpColor, OWins, 1 * 16 + 6, 38, 10);
					Text(pTmpBuffer, pTmpColor, L"Press any key to continue!", 1 * 16 + 6, 46, 17);
					Player2.Wins++;
					break;
				case 0:
					Blinking(pTmpBuffer, pTmpColor, Draw, 7, 8, 8, 43, 10);
					DrawObject(pTmpBuffer, pTmpColor, Draw, 1 * 16 + 8, 43, 10);
					Text(pTmpBuffer, pTmpColor, L"Press any key to continue!", 1 * 16 + 8, 46, 17);
					break;
				}
				if (music)
					PlaySound(L"main_music.wav", NULL, SND_FILENAME | SND_LOOP | SND_ASYNC);
				Display(pTmpBuffer, pTmpColor, 38, 9, 80, 17);
				_getch();
				if (sound)
					playSound(0);

				//Play Again
				drawNotiBoard(pTmpBuffer, pTmpColor, 44, 9, 30, 15);
				Text(pTmpBuffer, pTmpColor, L"PLAY AGAIN ?", 16 * 5 + 2, 53, 11);
				Text(pTmpBuffer, pTmpColor, L"YES", 16 * 5 + 6, 50, 14);
				Text(pTmpBuffer, pTmpColor, L"NO", 16 * 5 + 2, 65, 14);
				Text(pTmpBuffer, pTmpColor, L"|", 5 * 16 + 4, 59, 14);

				Display(pTmpBuffer, pTmpColor, 38, 9, 80, 17);

				int select = 1;
				while (1)
				{
					int move = toupper(_getch());

					if (move == 'D' || move == 77 || move == 'A' || move == 75)
					{
						if (sound)
							playSound(4);

						select = (select != 1) ? 1 : 2;
					}

					if (move == 13 || move == 32)
					{
						if (sound)
							playSound(0);

						if (select == 1)
						{
							Round++;
							isPlayAgain = 1;
							break;
						}
						else
						{
							delete[] pTmpBuffer;
							delete[] pTmpColor;
							return 2;
						}
					}
					switch (select)
					{
					case 1:
						Text(pTmpBuffer, pTmpColor, L"YES", 16 * 5 + 6, 50, 14);
						Text(pTmpBuffer, pTmpColor, L"NO", 16 * 5 + 2, 65, 14);
						break;
					case 2:
						Text(pTmpBuffer, pTmpColor, L"YES", 16 * 5 + 2, 50, 14);
						Text(pTmpBuffer, pTmpColor, L"NO", 16 * 5 + 6, 65, 14);
						break;
					}
					// Hiển thị
					Display(pTmpBuffer, pTmpColor, 38, 9, 80, 17);
				}
				delete[] pTmpBuffer;
				delete[] pTmpColor;
			}
			if (isPlayAgain)
				break;
		}
		for (int i = 0; i < BOARD_SIZE; i++)
		{
			for (int j = 0; j < BOARD_SIZE; j++)
				CARO_BOARD[i][j] = 0;
		}
		Move = { BOARD_SIZE / 2 - 1, BOARD_SIZE / 2 - 1, 1 };
		currentX = 37 + (BOARD_SIZE / 2 - 1) * 4;
		currentY = 2 + (BOARD_SIZE / 2 - 1) * 2;
		Player1.Time = 900;
		Player1.Moves = 0;
		Player2.Time = 900;
		Player2.Moves = 0;
		isPlayAgain = false;
	}
}

//Load file
vector<wstring> loadNamefile()
{
	FILE* file = nullptr;
	errno_t err = fopen_s(&file, "nameoffile.txt", "a+t");
	vector<wstring> listName{};
	if (file != NULL)
	{
		for (int j = 0; !feof(file); j++)
		{

			char tempCh[20]{};
			wstring tempWstr{};
			fgets(tempCh, sizeof(tempCh), file);

			if (tempCh[strlen(tempCh) - 1] == '\n')
				tempCh[strlen(tempCh) - 1] = '\0';
			for (int i = 0; i < strlen(tempCh); i++)
				tempWstr.push_back(tempCh[i]);
			listName.push_back(tempWstr);
		}
		listName.pop_back();

		fclose(file);
	}
	return listName;
}
void saveNamefile(vector<wstring> listName)
{
	FILE* file = nullptr;
	errno_t err = fopen_s(&file, "nameoffile.txt", "wt");
	if (file != NULL)
	{
		for (int i = 0; i < listName.size(); i++)
		{
			char namefile[20]{};

			const wchar_t* wch = listName[i].c_str();
			size_t size = (wcslen(wch) + 1) * sizeof(wchar_t);
			wcstombs(namefile, wch, size);
			fprintf(file, "%s\n", namefile);
		}
		fclose(file);
	}
}
void loadDatafile(wstring wstrfile, int& level)
{
	char namefile[24]{};

	const wchar_t* wch = wstrfile.c_str();
	size_t size = (wcslen(wch) + 1) * sizeof(wchar_t);
	wcstombs(namefile, wch, size);

	strcat_s(namefile, ".txt");

	FILE* file = nullptr;
	errno_t err = fopen_s(&file, namefile, "rt");
	if (file != NULL)
	{
		char tmpChar1[20]{};
		fgets(tmpChar1, sizeof(tmpChar1), file);
		if (tmpChar1[strlen(tmpChar1) - 1] == '\n') {
			tmpChar1[strlen(tmpChar1) - 1] = '\0';
		}
		for (int i = 0; i < strlen(tmpChar1); i++) {
			Player1.Name.push_back(tmpChar1[i]);
		}

		fscanf_s(file, "%i", &Player1.Wins);
		fscanf_s(file, "%i", &Player1.Time);
		fscanf_s(file, "%i", &Player1.Moves);

		char tmpChar2[20]{};
		if (fgets(tmpChar2, sizeof(tmpChar2), file) != NULL);
		fgets(tmpChar2, sizeof(tmpChar2), file);
		if (tmpChar2[strlen(tmpChar2) - 1] == '\n') {
			tmpChar2[strlen(tmpChar2) - 1] = '\0';
		}
		for (int i = 0; i < strlen(tmpChar2); i++) {
			Player2.Name.push_back(tmpChar2[i]);
		}

		fscanf_s(file, "%i", &Player2.Wins);
		fscanf_s(file, "%i", &Player2.Time);
		fscanf_s(file, "%i", &Player2.Moves);

		fscanf_s(file, "%i", &level);

		fscanf_s(file, "%i", &Round);
		fscanf_s(file, "%i", &Move._X);
		fscanf_s(file, "%i", &Move._Y);
		fscanf_s(file, "%i", &Move.flag);
		fscanf_s(file, "%i", &currentX);
		fscanf_s(file, "%i", &currentY);

		for (int j = 0; j < BOARD_SIZE; j++)
			for (int i = 0; i < BOARD_SIZE; i++)
				fscanf_s(file, "%i", &CARO_BOARD[i][j]);
		fclose(file);
	}
}
void renamefile(int idfile, vector<wstring>& listName, const char* newName)
{
	char oldName[24]{};

	const wchar_t* wch = listName[idfile].c_str();
	size_t size = (wcslen(wch) + 1) * sizeof(wchar_t);
	wcstombs(oldName, wch, size);

	strcat_s(oldName, ".txt");

	char newNametxt[24]{};
	strcpy_s(newNametxt, newName);
	strcat_s(newNametxt, ".txt");
	int err = rename(oldName, newNametxt);

	wstring temp{};
	for (int i = 0; i < strlen(newName); i++)
		temp.push_back(newName[i]);

	listName[idfile] = temp;
	saveNamefile(listName);
}
void deletefile(int idfile, vector<wstring>& listName)
{
	if (listName.size() <= 0) {
		return;
	}
	char filename[24]{};

	const wchar_t* wch = listName[idfile].c_str();
	size_t size = (wcslen(wch) + 1) * sizeof(wchar_t);
	wcstombs(filename, wch, size);

	strcat_s(filename, ".txt");

	int err = remove(filename);

	vector<wstring> temp{};
	int oldsz = listName.size();

	for (int i = idfile + 1; i < oldsz; i++)
		temp.push_back(listName[i]);
	for (int i = idfile; i < oldsz; i++)
		listName.pop_back();
	for (int i = 0; i < temp.size(); i++)
		listName.push_back(temp[i]);

	saveNamefile(listName);
}


